"use client";

import React, { useState, useEffect, useCallback } from "react";
import QRCode from "qrcode";
import { GitaAvatar } from "./VedicGraphics";
import {
  CheckCircle2,
  ShieldCheck,
  Clock,
  AlertTriangle,
  RefreshCw,
  Smartphone,
  CreditCard,
  Sparkles,
  XCircle,
  RotateCcw,
  QrCode,
  Copy,
  Share2,
  ExternalLink,
  Users,
  Building2,
  Lock,
} from "lucide-react";

interface SubscriptionScreensProps {
  token: string | null;
  userId?: number;
  trialExpiredReason?: boolean;
  onEntitlementUpdated: () => Promise<void>;
  onNavigateLegal: (section: "privacy" | "terms" | "help") => void;
  onStartChat: () => void;
  onResetTrialForQA: () => Promise<void>;
}

type PaymentMethodOption =
  | "phonepe"
  | "google_pay"
  | "paytm"
  | "bhim"
  | "other_person_phone";

interface UpiPaymentLinks {
  standardUpiUri: string;
  phonePeUri: string;
  googlePayUri: string;
  paytmUri: string;
  bhimUri: string;
}

interface ActiveOrderState {
  orderId: string;
  recipientUpiId: string;
  provider: string;
  amountInr: number;
  status: string; // 'pending' | 'verified' | 'failed' | 'expired' | 'refunded'
  submittedUtr?: string | null;
  providerTransactionId?: string | null;
  verificationMethod?: string | null;
  failureReason?: string | null;
  remainingWindowSeconds: number;
  isWindowExpired: boolean;
  upiQrIntentUri: string;
  upiLinks?: UpiPaymentLinks;
  securePaymentLinkPath: string;
  setupMessage: string | null;
  merchantDetails: {
    merchantName: string;
    merchantLegalName: string;
    merchantVpa: string;
    recipientUpiId: string;
    planName: string;
    amountInr: number;
    orderId: string;
  };
  customerAccount?: {
    customerUserId: number;
    customerName: string;
    customerEmail: string;
  };
}

export function SubscriptionScreens({
  token,
  userId,
  trialExpiredReason,
  onEntitlementUpdated,
  onNavigateLegal,
  onStartChat,
  onResetTrialForQA,
}: SubscriptionScreensProps) {
  const [provider, setProvider] = useState<PaymentMethodOption>("phonepe");
  const [explicitConsent, setExplicitConsent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [entitlement, setEntitlement] = useState<{
    isSubscribed: boolean;
    trialEligible: boolean;
    trialActive: boolean;
    trialExpired: boolean;
    remainingTrialSeconds: number;
    subscriptionStatus: string;
  } | null>(null);

  const [merchantInfo, setMerchantInfo] = useState<{
    merchantName: string;
    merchantLegalName: string;
    merchantVpa: string;
    recipientUpiId: string;
    planName: string;
    amountInr: number;
  }>({
    merchantName: "Gita AI",
    merchantLegalName: "Gita AI – Your Favorite Astrologer",
    merchantVpa: "7250595155@ibl",
    recipientUpiId: "7250595155@ibl",
    planName: "Gita AI Monthly Premium Subscription (30 Days)",
    amountInr: 49,
  });

  const [customerAccount, setCustomerAccount] = useState<{
    customerUserId: number;
    customerName: string;
    customerEmail: string;
  }>({
    customerUserId: 1,
    customerName: "Aarav Sharma",
    customerEmail: "aarav@gita-ai.in",
  });

  const [gatewayConfig, setGatewayConfig] = useState<{
    recipientUpiId: string;
    amountInr: number;
    anyLiveVerificationConfigured: boolean;
    providers: Record<string, boolean>;
    missingCredentialsExplanation?: string;
    requiredSetupSteps?: string[];
  } | null>(null);

  const [activeOrder, setActiveOrder] = useState<ActiveOrderState | null>(null);
  const [windowCountdown, setWindowCountdown] = useState<number>(300);
  const [qrDataUrl, setQrDataUrl] = useState<string>("");
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [utrInput, setUtrInput] = useState("");

  const [paymentsHistory, setPaymentsHistory] = useState<
    Array<{
      id: number;
      orderId: string;
      recipientUpiId?: string;
      provider: string;
      amountInr: number;
      status: string;
      submittedUtr?: string | null;
      providerTransactionId: string | null;
      verificationMethod: string | null;
      failureReason: string | null;
      createdAt: string;
    }>
  >([]);

  const loadSubscriptionData = useCallback(async () => {
    try {
      const res = await fetch("/api/subscription", {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (res.ok) {
        const data = await res.json();
        setEntitlement(data.entitlement);
        if (data.merchantDetails) {
          setMerchantInfo(data.merchantDetails);
        }
        if (data.customerAccount) {
          setCustomerAccount(data.customerAccount);
        }
        setGatewayConfig(data.gatewayConfig);
        setPaymentsHistory(data.payments || []);
      }
    } catch {
      // ignore
    }
  }, [token]);

  useEffect(() => {
    loadSubscriptionData();
  }, [loadSubscriptionData]);

  // Generate scannable QR code for the exact UPI URI (pa=7250595155@ibl&am=49.00&tr=<orderId>)
  useEffect(() => {
    if (!activeOrder) {
      setQrDataUrl("");
      return;
    }

    QRCode.toDataURL(activeOrder.upiQrIntentUri, {
      width: 240,
      margin: 2,
      color: {
        dark: "#2A162D",
        light: "#FFFFFF",
      },
    })
      .then((url) => setQrDataUrl(url))
      .catch(() => setQrDataUrl(""));
  }, [activeOrder]);

  // 5-Minute Payment Window Countdown & Server-Side Status Polling
  useEffect(() => {
    if (
      !activeOrder ||
      activeOrder.status === "verified" ||
      activeOrder.status === "failed" ||
      activeOrder.status === "expired" ||
      activeOrder.status === "refunded"
    ) {
      return;
    }

    const countdownInterval = setInterval(() => {
      setWindowCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(countdownInterval);
          fetch("/api/subscription", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              ...(token ? { Authorization: `Bearer ${token}` } : {}),
            },
            body: JSON.stringify({
              action: "expire_order_window",
              userId,
              orderId: activeOrder.orderId,
            }),
          })
            .then((r) => r.json())
            .then(async (data) => {
              if (data.payment) {
                setActiveOrder((curr) =>
                  curr
                    ? {
                        ...curr,
                        ...data.payment,
                        setupMessage: curr.setupMessage,
                      }
                    : null
                );
              }
              if (data.message) {
                if (data.payment?.status === "verified") {
                  setStatusMessage(data.message);
                } else {
                  setErrorMessage(data.message);
                }
              }
              await loadSubscriptionData();
              await onEntitlementUpdated();
            })
            .catch(() => {});
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    // Only poll automatically if a live verification provider is configured and order is pending
    const pollInterval = gatewayConfig?.anyLiveVerificationConfigured
      ? setInterval(async () => {
          try {
            const res = await fetch(
              `/api/subscription?orderId=${encodeURIComponent(
                activeOrder.orderId
              )}`
            );
            if (res.ok) {
              const data = await res.json();
              if (data.order && data.order.status !== activeOrder.status) {
                setActiveOrder((curr) =>
                  curr
                    ? {
                        ...curr,
                        ...data.order,
                        setupMessage: curr.setupMessage,
                      }
                    : null
                );
                if (data.order.status === "verified") {
                  setStatusMessage(
                    `Payment successful! Verified ₹49 payment to ${data.order.recipientUpiId} for Order ${data.order.orderId}. Premium chat is now unlocked!`
                  );
                  setErrorMessage(null);
                  await loadSubscriptionData();
                  await onEntitlementUpdated();
                } else if (data.order.status === "failed") {
                  setErrorMessage(
                    data.order.failureReason ||
                      "Payment failed verification. Please use Retry Payment."
                  );
                  await loadSubscriptionData();
                } else if (data.order.status === "expired") {
                  setErrorMessage(
                    "5-minute payment window expired. Please tap Retry Payment."
                  );
                  await loadSubscriptionData();
                }
              }
            }
          } catch {
            // ignore network poll hiccup
          }
        }, 4000)
      : null;

    return () => {
      clearInterval(countdownInterval);
      if (pollInterval) clearInterval(pollInterval);
    };
  }, [
    activeOrder,
    gatewayConfig?.anyLiveVerificationConfigured,
    token,
    userId,
    loadSubscriptionData,
    onEntitlementUpdated,
  ]);

  const handleInitiateOrder = async (overrideProvider?: PaymentMethodOption) => {
    const selectedProvider = overrideProvider || provider;

    if (!explicitConsent) {
      setErrorMessage(
        "Kripya payment shuru karne se pehle ₹49/month billing aur renewal terms par apni sehmati (checkbox) dein."
      );
      return;
    }

    setLoading(true);
    setErrorMessage(null);
    setStatusMessage(null);
    setUtrInput("");

    try {
      const res = await fetch("/api/subscription", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          action: "create_order",
          userId,
          provider: selectedProvider,
          explicitConsent: true,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setErrorMessage(data.error || "Could not create order");
      } else {
        setActiveOrder({
          ...data.order,
          setupMessage: data.setupMessage,
        });
        setWindowCountdown(data.order.remainingWindowSeconds || 300);
        setStatusMessage(
          `Order ${data.order.orderId} created for recipient UPI ID ${data.order.recipientUpiId} (₹49.00). Waiting for independent server-side payment verification.`
        );
        loadSubscriptionData();
      }
    } catch {
      setErrorMessage("Network error while creating payment order.");
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyPaymentWithServer = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!activeOrder) return;
    setLoading(true);
    setErrorMessage(null);
    setStatusMessage(null);

    try {
      const res = await fetch("/api/subscription", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          action: "verify_payment",
          userId,
          orderId: activeOrder.orderId,
          utr: utrInput.trim() || undefined,
        }),
      });
      const data = await res.json();

      if (data.payment) {
        setActiveOrder((prev) =>
          prev
            ? {
                ...prev,
                ...data.payment,
                setupMessage: prev.setupMessage,
              }
            : null
        );
      }

      if (res.ok && data.verified && data.payment?.status === "verified") {
        setStatusMessage(data.message);
        setErrorMessage(null);
        await loadSubscriptionData();
        await onEntitlementUpdated();
      } else {
        setErrorMessage(
          data.error ||
            data.message ||
            "Payment could not be verified. Premium remains locked until genuinely verified by the payment provider."
        );
        await loadSubscriptionData();
        await onEntitlementUpdated();
      }
    } catch {
      setErrorMessage("Could not verify payment status with server.");
    } finally {
      setLoading(false);
    }
  };

  const handleRetryPayment = async () => {
    setExplicitConsent(true);
    await handleInitiateOrder(provider);
  };

  const handleReportUpiDecline = async (reasonText?: string) => {
    if (!activeOrder) return;
    setLoading(true);
    setErrorMessage(null);
    setStatusMessage(null);
    try {
      const res = await fetch("/api/subscription", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          action: "report_upi_decline",
          userId,
          orderId: activeOrder.orderId,
          failureReason:
            reasonText ||
            "Your payment is declined for security reasons. Please try using a mobile number, UPI ID, or QR code.",
        }),
      });
      const data = await res.json();
      if (data.payment) {
        setActiveOrder((prev) =>
          prev
            ? {
                ...prev,
                ...data.payment,
                setupMessage: prev.setupMessage,
              }
            : null
        );
      }
      setErrorMessage(
        data.error ||
          data.message ||
          "Your payment is declined for security reasons. Please try using a mobile number, UPI ID, or QR code."
      );
      await loadSubscriptionData();
    } catch {
      setErrorMessage("Could not record payment decline status.");
    } finally {
      setLoading(false);
    }
  };

  const handleLifecycleAction = async (
    action: "cancel_subscription" | "simulate_expiry" | "restore_purchases"
  ) => {
    setLoading(true);
    setErrorMessage(null);
    setStatusMessage(null);
    try {
      const res = await fetch("/api/subscription", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ action, userId }),
      });
      const data = await res.json();
      if (!res.ok) {
        setErrorMessage(data.message || data.error || "Operation failed");
      } else {
        setStatusMessage(data.message);
        await loadSubscriptionData();
        await onEntitlementUpdated();
      }
    } finally {
      setLoading(false);
    }
  };

  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  };

  const paymentOptions: Array<{
    id: PaymentMethodOption;
    title: string;
    sub: string;
    badge?: string;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    {
      id: "phonepe",
      title: "PhonePe",
      sub: "Pay ₹49 directly to 7250595155@ibl via PhonePe UPI",
      icon: Smartphone,
    },
    {
      id: "google_pay",
      title: "Google Pay",
      sub: "Pay ₹49 directly to 7250595155@ibl via Google Pay (GPay)",
      icon: Smartphone,
    },
    {
      id: "paytm",
      title: "Paytm",
      sub: "Pay ₹49 directly to 7250595155@ibl via Paytm UPI",
      icon: CreditCard,
    },
    {
      id: "bhim",
      title: "BHIM & Other Compatible UPI Apps",
      sub: "Pay ₹49 to 7250595155@ibl via BHIM, Amazon Pay, Cred, or any bank UPI app",
      icon: ShieldCheck,
    },
    {
      id: "other_person_phone",
      title: "Pay using another person's phone (UPI QR & Link)",
      sub: "Scan dynamic QR code or share payment link for 7250595155@ibl (₹49)",
      badge: "QR & Link",
      icon: QrCode,
    },
  ];

  const fullShareableLink =
    activeOrder && typeof window !== "undefined"
      ? `${window.location.origin}${activeOrder.securePaymentLinkPath}`
      : activeOrder?.securePaymentLinkPath || "";

  return (
    <div className="p-4 space-y-5 pb-24">
      {/* Trial Expired Notice Banner if redirected from 15s Trial */}
      {(trialExpiredReason || entitlement?.trialExpired) &&
        !entitlement?.isSubscribed && (
          <div className="bg-gradient-to-r from-[#7C2D86]/15 via-[#E14B7B]/15 to-[#D4AF37]/20 border border-[#D4AF37] rounded-2xl p-4 flex items-start gap-3">
            <Clock className="w-5 h-5 text-[#B8860B] shrink-0 mt-0.5" />
            <div className="text-xs">
              <div className="font-bold text-[#2A162D]">
                Aapka 15-Second Free Trial Samapt Ho Gaya Hai
              </div>
              <p className="text-[#6E5273] mt-0.5 leading-relaxed">
                Gita AI se asimit baat-cheet, kundli vishleshan aur vyaktigat
                jyotish margdarshan jari rakhne ke liye ₹49/month plan chunein.
              </p>
            </div>
          </div>
        )}

      {/* Main Premium Subscription Hero Card */}
      <div className="bg-gradient-to-br from-[#FFF9F5] via-[#FDF3EE] to-[#F7E5EC] border-2 border-[#D4AF37]/70 rounded-3xl p-5 shadow-md relative overflow-hidden">
        <div className="flex items-center gap-4">
          <GitaAvatar size="lg" showOnline={true} />
          <div>
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#D4AF37]/20 text-[#B8860B] text-[11px] font-bold uppercase tracking-wider">
              <Sparkles className="w-3 h-3" /> Gita AI Ashirwad Plan
            </span>
            <h2 className="text-xl font-serif-vedic text-[#2A162D] mt-1">
              Your Favorite Astrologer
            </h2>
            <div className="flex items-baseline gap-1.5 mt-1">
              <span className="text-2xl font-bold font-mono-vedic text-[#7C2D86]">
                ₹49
              </span>
              <span className="text-xs font-semibold text-[#6E5273]">
                / month (30 Days)
              </span>
            </div>
          </div>
        </div>

        {/* Current Subscription Status Pill */}
        {entitlement && (
          <div className="mt-4 p-3 rounded-2xl bg-white/90 border border-[#EFE1E6] flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="text-[#6E5273] font-medium">Current Status:</span>
              <span
                className={`px-2.5 py-0.5 rounded-full font-bold uppercase text-[10px] ${
                  entitlement.isSubscribed
                    ? "bg-[#1E7E5A]/15 text-[#1E7E5A]"
                    : entitlement.subscriptionStatus === "pending"
                    ? "bg-[#D97706]/15 text-[#D97706]"
                    : "bg-[#C93B2B]/15 text-[#C93B2B]"
                }`}
              >
                {entitlement.isSubscribed
                  ? "Payment successful • ACTIVE (₹49/MO)"
                  : entitlement.subscriptionStatus === "pending"
                  ? "LOCKED • Waiting for verified payment"
                  : `LOCKED (${entitlement.subscriptionStatus})`}
              </span>
            </div>
            {entitlement.isSubscribed && (
              <button
                onClick={onStartChat}
                className="text-xs font-bold text-[#7C2D86] underline cursor-pointer"
              >
                Chat Now →
              </button>
            )}
          </div>
        )}

        {/* Direct Recipient UPI ID Card: 7250595155@ibl */}
        <div className="mt-4 p-4 rounded-2xl bg-white border-2 border-[#7C2D86]/40 space-y-2 text-xs shadow-2xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 font-bold text-[#7C2D86]">
              <Building2 className="w-4 h-4" />
              <span>Direct UPI Payment Recipient</span>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-[#1E7E5A]/15 text-[#1E7E5A] font-mono-vedic font-bold text-[11px]">
              ₹49.00 / month
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] flex items-center justify-between gap-2">
            <div>
              <div className="text-[10px] uppercase text-[#6E5273] font-semibold">
                Payee UPI ID (PhonePe / GPay / Paytm / BHIM)
              </div>
              <div className="text-sm font-mono-vedic font-bold text-[#2A162D]">
                7250595155@ibl
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                if (typeof navigator !== "undefined" && navigator.clipboard) {
                  navigator.clipboard.writeText("7250595155@ibl");
                  setCopiedUpi(true);
                  setTimeout(() => setCopiedUpi(false), 2000);
                }
              }}
              className="px-3 py-1.5 rounded-lg bg-[#7C2D86] text-white text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer shrink-0"
            >
              <Copy className="w-3 h-3" />
              {copiedUpi ? "Copied!" : "Copy UPI ID"}
            </button>
          </div>

          <div className="grid grid-cols-2 gap-y-1 text-[11px] pt-1">
            <span className="text-[#6E5273]">Merchant Recipient Name:</span>
            <span className="font-semibold text-[#2A162D] text-right">
              {merchantInfo.merchantName} (7250595155@ibl)
            </span>
            <span className="text-[#6E5273]">
              Customer Gita AI Account (Subscriber):
            </span>
            <span className="font-semibold text-[#2A162D] text-right truncate">
              {customerAccount.customerName} ({customerAccount.customerEmail})
            </span>
          </div>
        </div>

        {/* Honest Automatic Verification Availability Banner (Requirement 9) */}
        {gatewayConfig && !gatewayConfig.anyLiveVerificationConfigured && (
          <div className="mt-4 p-4 rounded-2xl bg-[#D97706]/10 border-2 border-[#D97706]/40 text-xs space-y-2">
            <div className="font-bold text-[#B8860B] flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>
                Automatic Verification Status for 7250595155@ibl: Merchant API
                Credentials Required
              </span>
            </div>
            <p className="text-[11px] text-[#2A162D] leading-relaxed">
              {gatewayConfig.missingCredentialsExplanation}
            </p>
            {gatewayConfig.requiredSetupSteps && (
              <div className="space-y-1 pt-1 border-t border-[#D97706]/25 text-[11px] text-[#6E5273]">
                <div className="font-bold text-[#2A162D]">
                  Required Merchant Integration & Credentials to Enable
                  Automatic Verification:
                </div>
                <ul className="list-disc pl-4 space-y-1">
                  {gatewayConfig.requiredSetupSteps.map((step, idx) => (
                    <li key={idx}>{step}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}

        {/* Status / Error Alerts */}
        {statusMessage && (
          <div className="mt-4 p-3.5 rounded-2xl bg-[#1E7E5A]/15 border border-[#1E7E5A]/30 text-[#1E7E5A] text-xs font-medium">
            {statusMessage}
          </div>
        )}
        {errorMessage && (
          <div className="mt-4 p-3.5 rounded-2xl bg-[#C93B2B]/15 border border-[#C93B2B]/30 text-[#C93B2B] text-xs font-medium">
            {errorMessage}
          </div>
        )}

        {/* Payment Method Selection */}
        {!entitlement?.isSubscribed && (
          <div className="mt-5 space-y-3">
            <div className="text-xs font-bold text-[#2A162D]">
              Select UPI App to Pay ₹49/month to 7250595155@ibl:
            </div>

            <div className="grid grid-cols-1 gap-2">
              {paymentOptions.map((m) => {
                const Icon = m.icon;
                const selected = provider === m.id;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setProvider(m.id)}
                    className={`w-full text-left p-3.5 rounded-2xl border transition flex items-center gap-3 cursor-pointer ${
                      selected
                        ? "bg-white border-2 border-[#7C2D86] shadow-xs"
                        : "bg-white/75 border-[#EFE1E6] hover:bg-white"
                    }`}
                  >
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                        selected
                          ? "bg-[#7C2D86] text-white"
                          : "bg-[#FDF3EE] text-[#7C2D86]"
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-[#2A162D]">
                          {m.title}
                        </span>
                        {m.badge && (
                          <span className="px-2 py-0.5 rounded-full bg-[#D4AF37]/25 text-[#B8860B] text-[10px] font-bold">
                            {m.badge}
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-[#6E5273] leading-snug mt-0.5">
                        {m.sub}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Clear Billing Terms & Explicit Consent Checkbox */}
            <div className="p-3.5 rounded-2xl bg-white/90 border border-[#EFE1E6] space-y-2.5 text-[11px] text-[#6E5273]">
              <div>
                <strong className="text-[#2A162D]">
                  Strict Verification Policy:
                </strong>{" "}
                Plan price is <strong>₹49 per month</strong> paid to{" "}
                <strong className="font-mono-vedic text-[#7C2D86]">
                  7250595155@ibl
                </strong>
                . Premium access is locked until the backend independently
                verifies your ₹49 payment via an authorized bank or payment
                gateway API. Premium is never unlocked from UPI redirects,
                screenshots, unverified UTR entries, or simulated status.
              </div>

              <label className="flex items-start gap-2.5 text-xs text-[#2A162D] font-medium pt-1 cursor-pointer">
                <input
                  type="checkbox"
                  checked={explicitConsent}
                  onChange={(e) => setExplicitConsent(e.target.checked)}
                  className="mt-0.5 accent-[#7C2D86]"
                />
                <span>
                  I explicitly consent to pay{" "}
                  <strong className="font-mono-vedic">₹49/month</strong> to{" "}
                  <strong className="font-mono-vedic">7250595155@ibl</strong>{" "}
                  and agree to the Terms of Service and Privacy Policy.
                </span>
              </label>
            </div>

            <button
              type="button"
              disabled={loading}
              onClick={() => handleInitiateOrder()}
              className="w-full py-4 px-6 rounded-full bg-gradient-to-r from-[#7C2D86] via-[#C93B76] to-[#E14B7B] text-white font-bold text-sm shadow-lg hover:opacity-95 transition cursor-pointer disabled:opacity-50"
            >
              {loading
                ? "Generating Unique Order Reference..."
                : `Generate ₹49 UPI Request & QR for 7250595155@ibl`}
            </button>
          </div>
        )}
      </div>

      {/* ACTIVE ORDER: UPI PAYMENT REQUEST, QR CODE & INDEPENDENT SERVER VERIFICATION */}
      {activeOrder && (
        <div className="bg-white rounded-3xl border-2 border-[#7C2D86]/40 p-5 shadow-md space-y-4">
          {/* Header with Unique Order Reference & Status */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#EFE1E6] pb-3">
            <div>
              <span className="text-[10px] font-mono-vedic uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-[#7C2D86]/10 text-[#7C2D86] font-bold">
                Unique Order Ref: {activeOrder.orderId}
              </span>
              <h3 className="text-sm font-bold text-[#2A162D] mt-1">
                Pay ₹{activeOrder.amountInr}.00 to{" "}
                <span className="font-mono-vedic text-[#7C2D86]">
                  {activeOrder.recipientUpiId}
                </span>
              </h3>
            </div>

            <div>
              {activeOrder.status === "verified" ? (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1E7E5A]/15 text-[#1E7E5A] text-xs font-bold">
                  <CheckCircle2 className="w-4 h-4" />
                  Payment successful
                </span>
              ) : activeOrder.status === "failed" ? (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#C93B2B]/15 text-[#C93B2B] text-xs font-bold">
                  <XCircle className="w-4 h-4" />
                  Payment failed
                </span>
              ) : activeOrder.status === "expired" || windowCountdown <= 0 ? (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#C93B2B]/15 text-[#C93B2B] text-xs font-bold">
                  <AlertTriangle className="w-4 h-4" />
                  5-Min Window Expired
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#D97706]/15 text-[#D97706] text-xs font-bold">
                  <Lock className="w-3.5 h-3.5" />
                  Waiting for payment ({formatTimer(windowCountdown)})
                </span>
              )}
            </div>
          </div>

          {/* Order & Recipient Summary */}
          <div className="p-3.5 rounded-2xl bg-[#FDF3EE] border border-[#EFE1E6] space-y-1 text-xs">
            <div className="flex justify-between">
              <span className="text-[#6E5273]">
                Merchant Recipient (Payee UPI ID):
              </span>
              <span className="font-mono-vedic font-bold text-[#7C2D86]">
                {activeOrder.recipientUpiId} ({activeOrder.merchantDetails.merchantName})
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#6E5273]">Unique Order Reference:</span>
              <span className="font-mono-vedic font-bold text-[#2A162D]">
                {activeOrder.orderId}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#6E5273]">
                Customer Gita AI Account (Subscriber):
              </span>
              <span className="font-bold text-[#2A162D]">
                {activeOrder.customerAccount?.customerName ||
                  customerAccount.customerName}{" "}
                (
                {activeOrder.customerAccount?.customerEmail ||
                  customerAccount.customerEmail}
                )
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#6E5273]">Exact Amount:</span>
              <span className="font-mono-vedic font-bold text-[#1E7E5A]">
                ₹{activeOrder.amountInr}.00 INR
              </span>
            </div>
          </div>

          {/* QR CODE & DIRECT UPI APP DEEP LINKS FOR 7250595155@ibl */}
          {(activeOrder.status === "pending" ||
            activeOrder.status === "created") &&
            windowCountdown > 0 && (
              <div className="space-y-4">
                <div className="bg-gradient-to-b from-[#FFF9F5] to-[#FDF3EE] border-2 border-[#D4AF37]/60 rounded-2xl p-4 text-center space-y-3">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#7C2D86]/10 text-[#7C2D86] text-[11px] font-bold">
                    <QrCode className="w-3.5 h-3.5" />
                    Scan with PhonePe, Google Pay, Paytm, BHIM or Another Phone
                  </div>

                  <div className="bg-white p-3 rounded-2xl border-2 border-[#7C2D86]/20 inline-block shadow-sm">
                    {qrDataUrl ? (
                      <img
                        src={qrDataUrl}
                        alt={`UPI QR for 7250595155@ibl Order ${activeOrder.orderId}`}
                        className="w-48 h-48 mx-auto"
                      />
                    ) : (
                      <div className="w-48 h-48 flex items-center justify-center text-xs text-[#6E5273]">
                        Generating UPI QR...
                      </div>
                    )}
                    <div className="text-[11px] font-mono-vedic font-bold text-[#2A162D] mt-1">
                      UPI ID: {activeOrder.recipientUpiId} • ₹49.00
                    </div>
                    <div className="text-[10px] font-mono-vedic text-[#6E5273]">
                      Ref: {activeOrder.orderId}
                    </div>
                    {qrDataUrl && (
                      <div className="mt-2">
                        <a
                          href={qrDataUrl}
                          download={`GitaAI-UPI-QR-${activeOrder.orderId}.png`}
                          className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-[#7C2D86]/10 text-[#7C2D86] text-[10px] font-bold hover:bg-[#7C2D86] hover:text-white transition"
                        >
                          <QrCode className="w-3 h-3" />
                          Save QR Image (Scan from Gallery in UPI App)
                        </a>
                      </div>
                    )}
                  </div>

                  {/* Direct UPI App Intent Buttons (All use validated canonical upi://pay URI) */}
                  <div className="space-y-2 text-left">
                    <div className="text-[11px] font-bold text-[#2A162D] text-center">
                      Or Tap to Open a Compatible UPI App on Your Phone:
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      <a
                        href={
                          activeOrder.upiLinks?.phonePeUri ||
                          activeOrder.upiQrIntentUri
                        }
                        className="py-2.5 px-3 rounded-xl bg-[#5F259F] text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-2xs"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        PhonePe
                      </a>
                      <a
                        href={
                          activeOrder.upiLinks?.googlePayUri ||
                          activeOrder.upiQrIntentUri
                        }
                        className="py-2.5 px-3 rounded-xl bg-[#1A73E8] text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-2xs"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        Google Pay
                      </a>
                      <a
                        href={
                          activeOrder.upiLinks?.paytmUri ||
                          activeOrder.upiQrIntentUri
                        }
                        className="py-2.5 px-3 rounded-xl bg-[#00B9F1] text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-2xs"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        Paytm
                      </a>
                      <a
                        href={
                          activeOrder.upiLinks?.bhimUri ||
                          activeOrder.upiQrIntentUri
                        }
                        className="py-2.5 px-3 rounded-xl bg-[#E85D04] text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-2xs"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        BHIM UPI
                      </a>
                      <a
                        href={activeOrder.upiQrIntentUri}
                        className="col-span-2 sm:col-span-2 py-2.5 px-3 rounded-xl bg-[#7C2D86] text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-2xs"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        Any Installed UPI App (₹49.00)
                      </a>
                    </div>
                  </div>

                  {/* Shareable Link for Another Person's Phone */}
                  <div className="space-y-2 text-left bg-white p-3 rounded-xl border border-[#EFE1E6]">
                    <div className="text-[11px] font-bold text-[#2A162D] flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-[#7C2D86]" />
                      Pay Using Another Person&apos;s Phone (Share Link):
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        readOnly
                        value={fullShareableLink}
                        className="flex-1 h-9 px-2.5 rounded-lg bg-[#FDF3EE] border border-[#E5D4E8] text-[11px] font-mono-vedic text-[#6E5273]"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (
                            typeof navigator !== "undefined" &&
                            navigator.clipboard
                          ) {
                            navigator.clipboard.writeText(fullShareableLink);
                            setCopiedLink(true);
                            setTimeout(() => setCopiedLink(false), 2500);
                          }
                        }}
                        className="px-3 h-9 rounded-lg bg-[#7C2D86] text-white text-xs font-semibold inline-flex items-center gap-1 cursor-pointer shrink-0"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        {copiedLink ? "Copied!" : "Copy"}
                      </button>
                    </div>
                    <div className="flex gap-2 pt-1">
                      <a
                        href={activeOrder.securePaymentLinkPath}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 py-2 px-3 rounded-lg bg-[#FDF3EE] border border-[#7C2D86]/30 text-[#7C2D86] font-semibold text-[11px] flex items-center justify-center gap-1.5"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        Open Payer Page
                      </a>
                      <button
                        type="button"
                        onClick={() => {
                          const shareText = `Namaste! Please pay ₹49.00 to UPI ID ${activeOrder.recipientUpiId} for my Gita AI subscription (Order ${activeOrder.orderId}): ${fullShareableLink}`;
                          if (
                            typeof window !== "undefined"
                          ) {
                            window.open(
                              `https://wa.me/?text=${encodeURIComponent(
                                shareText
                              )}`,
                              "_blank"
                            );
                          }
                        }}
                        className="flex-1 py-2 px-3 rounded-lg bg-[#1E7E5A]/10 border border-[#1E7E5A]/30 text-[#1E7E5A] font-semibold text-[11px] flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                        Share via WhatsApp
                      </button>
                    </div>
                  </div>
                </div>

                {/* INDEPENDENT SERVER-SIDE UTR & ORDER VERIFICATION FORM */}
                <form
                  onSubmit={handleVerifyPaymentWithServer}
                  className="p-4 rounded-2xl bg-[#FDF3EE] border border-[#E5D4E8] space-y-3"
                >
                  <div className="text-xs font-bold text-[#2A162D]">
                    Verify Payment & UTR via Authorized Provider API:
                  </div>
                  <p className="text-[11px] text-[#6E5273] leading-relaxed">
                    Enter your 12-digit UPI UTR / Reference Number (optional if
                    webhook is active) to trigger an independent server-side
                    lookup of transaction status, ₹49 amount, recipient (
                    <span className="font-mono-vedic font-semibold">
                      7250595155@ibl
                    </span>
                    ), and Order ID.{" "}
                    <strong>
                      Note: Submitting a UTR without provider confirmation will
                      NOT unlock Premium.
                    </strong>
                  </p>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <input
                      type="text"
                      placeholder="12-digit UPI UTR / RRN (e.g. 412345678901)"
                      value={utrInput}
                      onChange={(e) => setUtrInput(e.target.value)}
                      className="flex-1 h-10 px-3 rounded-xl bg-white border border-[#E5D4E8] text-xs font-mono-vedic"
                    />
                    <button
                      type="submit"
                      disabled={loading}
                      className="px-4 h-10 rounded-xl bg-[#7C2D86] text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shrink-0 disabled:opacity-50"
                    >
                      <RefreshCw
                        className={`w-3.5 h-3.5 ${
                          loading ? "animate-spin" : ""
                        }`}
                      />
                      Verify Payment Status
                    </button>
                  </div>

                  {/* Report UPI App Security Decline (Stops polling & shows actual bank/app failure reason) */}
                  <div className="pt-2 border-t border-[#E5D4E8] flex flex-wrap items-center justify-between gap-2 text-[11px]">
                    <span className="text-[#6E5273]">
                      Did your UPI app decline the deep-link payment for security
                      reasons?
                    </span>
                    <button
                      type="button"
                      disabled={loading}
                      onClick={() =>
                        handleReportUpiDecline(
                          "Your payment is declined for security reasons. Please try using a mobile number, UPI ID, or QR code."
                        )
                      }
                      className="px-3 py-1 rounded-lg bg-[#C93B2B]/10 text-[#C93B2B] font-semibold hover:bg-[#C93B2B] hover:text-white transition cursor-pointer"
                    >
                      Report UPI App Decline Error
                    </button>
                  </div>
                </form>
              </div>
            )}

          {/* STATE 2: PAYMENT SUCCESSFUL (Only reachable if a real configured provider API or signed webhook confirms payment) */}
          {activeOrder.status === "verified" && (
            <div className="p-5 rounded-2xl bg-[#1E7E5A]/10 border-2 border-[#1E7E5A]/40 text-center space-y-3">
              <CheckCircle2 className="w-10 h-10 text-[#1E7E5A] mx-auto" />
              <div>
                <div className="text-base font-bold text-[#1E7E5A]">
                  Payment successful
                </div>
                <p className="text-xs text-[#2A162D] mt-1">
                  Independent server verification confirmed ₹49.00 received at{" "}
                  <span className="font-mono-vedic font-bold">
                    {activeOrder.recipientUpiId}
                  </span>{" "}
                  for Order{" "}
                  <span className="font-mono-vedic font-bold">
                    {activeOrder.orderId}
                  </span>
                  .
                </p>
              </div>
              <button
                type="button"
                onClick={onStartChat}
                className="py-3 px-6 rounded-full bg-[#1E7E5A] text-white font-bold text-xs shadow-md hover:opacity-95 cursor-pointer"
              >
                Start Unlimited Chat with Gita AI →
              </button>
            </div>
          )}

          {/* STATE 3: PAYMENT FAILED OR 5-MINUTE WINDOW EXPIRED — SHOW RETRY OPTION */}
          {(activeOrder.status === "failed" ||
            activeOrder.status === "expired" ||
            (activeOrder.status !== "verified" && windowCountdown <= 0)) && (
            <div className="p-5 rounded-2xl bg-[#C93B2B]/10 border-2 border-[#C93B2B]/30 text-center space-y-3">
              <AlertTriangle className="w-9 h-9 text-[#C93B2B] mx-auto" />
              <div>
                <div className="text-sm font-bold text-[#C93B2B]">
                  {activeOrder.status === "failed"
                    ? "Payment Failed Verification"
                    : "5-Minute Payment Window Expired"}
                </div>
                <p className="text-xs text-[#6E5273] mt-1">
                  {activeOrder.failureReason ||
                    "No verified payment confirmation was received within the 5-minute window."}
                </p>
              </div>
              <button
                type="button"
                disabled={loading}
                onClick={handleRetryPayment}
                className="py-3 px-6 rounded-full bg-gradient-to-r from-[#7C2D86] to-[#E14B7B] text-white font-bold text-xs shadow-md hover:opacity-95 inline-flex items-center gap-2 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                Retry Payment (Generate New Unique Order Ref)
              </button>
            </div>
          )}
        </div>
      )}

      {/* SUBSCRIPTION MANAGEMENT & QA TESTING HARNESS */}
      <div className="bg-white rounded-3xl border border-[#EFE1E6] p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-[#2A162D]">
              Subscription Management & Restore Purchases
            </h3>
            <p className="text-xs text-[#6E5273]">
              Manage your ₹49/month plan, restore verified purchases to{" "}
              <span className="font-mono-vedic">7250595155@ibl</span>, or reset
              the 15s free trial.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            disabled={loading}
            onClick={() => handleLifecycleAction("restore_purchases")}
            className="px-4 py-2.5 rounded-full bg-[#FDF3EE] border border-[#7C2D86]/30 text-xs font-semibold text-[#7C2D86] hover:bg-[#7C2D86] hover:text-white transition cursor-pointer"
          >
            Restore Verified Purchases
          </button>

          <button
            type="button"
            disabled={loading}
            onClick={() => handleLifecycleAction("cancel_subscription")}
            className="px-4 py-2.5 rounded-full bg-[#FDF3EE] border border-[#C93B2B]/30 text-xs font-semibold text-[#C93B2B] hover:bg-[#C93B2B] hover:text-white transition cursor-pointer"
          >
            Cancel Subscription
          </button>

          <button
            type="button"
            disabled={loading}
            onClick={onResetTrialForQA}
            className="px-4 py-2.5 rounded-full bg-[#7C2D86]/10 border border-[#7C2D86]/30 text-xs font-semibold text-[#7C2D86] hover:bg-[#7C2D86] hover:text-white transition cursor-pointer"
          >
            QA: Reset 15-Second Free Trial
          </button>
        </div>

        {/* Past Payment Records */}
        {paymentsHistory.length > 0 && (
          <div className="pt-3 border-t border-[#EFE1E6] space-y-2">
            <div className="text-xs font-bold text-[#2A162D]">
              Your Order & Verification History:
            </div>
            {paymentsHistory.slice(0, 4).map((p) => (
              <div
                key={p.id}
                className="p-3 rounded-xl bg-[#FFF9F5] border border-[#EFE1E6] flex items-center justify-between text-xs"
              >
                <div>
                  <div className="font-mono-vedic font-semibold text-[#2A162D]">
                    {p.orderId}
                  </div>
                  <div className="text-[11px] text-[#6E5273]">
                    To: {p.recipientUpiId || "7250595155@ibl"} • ₹{p.amountInr}{" "}
                    • {p.provider.replace(/_/g, " ").toUpperCase()}
                  </div>
                </div>
                <span
                  className={`px-2.5 py-0.5 rounded-full font-bold uppercase text-[10px] ${
                    p.status === "verified"
                      ? "bg-[#1E7E5A]/15 text-[#1E7E5A]"
                      : p.status === "pending"
                      ? "bg-[#D97706]/15 text-[#D97706]"
                      : "bg-[#C93B2B]/15 text-[#C93B2B]"
                  }`}
                >
                  {p.status === "verified"
                    ? "Verified"
                    : p.status === "pending"
                    ? "Waiting (Locked)"
                    : p.status}
                </span>
              </div>
            ))}
          </div>
        )}

        {/* Legal Links Footer */}
        <div className="pt-3 border-t border-[#EFE1E6] flex items-center justify-center gap-4 text-xs text-[#7C2D86] font-semibold">
          <button
            type="button"
            onClick={() => onNavigateLegal("terms")}
            className="underline cursor-pointer"
          >
            Terms of Service
          </button>
          <span>•</span>
          <button
            type="button"
            onClick={() => onNavigateLegal("privacy")}
            className="underline cursor-pointer"
          >
            Privacy Policy
          </button>
          <span>•</span>
          <button
            type="button"
            onClick={() => onNavigateLegal("help")}
            className="underline cursor-pointer"
          >
            Help & Refund Policy
          </button>
        </div>
      </div>
    </div>
  );
}
