"use client";

import React from "react";
import type { KundliHouseData } from "@/lib/astrology";

export function SacredYantraHalo({ className = "w-28 h-28" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 200 200"
      className={`${className} animate-spin-slow pointer-events-none select-none`}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle
        cx="100"
        cy="100"
        r="94"
        stroke="#D4AF37"
        strokeWidth="1.2"
        strokeDasharray="4 4"
        opacity="0.65"
      />
      <circle
        cx="100"
        cy="100"
        r="82"
        stroke="#7C2D86"
        strokeWidth="1"
        opacity="0.35"
      />
      {/* 8-Pointed Star (Ashta Lakshmi / Surya Mandala) */}
      <rect
        x="42"
        y="42"
        width="116"
        height="116"
        stroke="#D4AF37"
        strokeWidth="1.2"
        opacity="0.5"
      />
      <rect
        x="42"
        y="42"
        width="116"
        height="116"
        transform="rotate(45 100 100)"
        stroke="#E14B7B"
        strokeWidth="1.2"
        opacity="0.45"
      />
      {/* Cardinal Lotus Dots */}
      <circle cx="100" cy="6" r="3" fill="#D4AF37" />
      <circle cx="194" cy="100" r="3" fill="#D4AF37" />
      <circle cx="100" cy="194" r="3" fill="#D4AF37" />
      <circle cx="6" cy="100" r="3" fill="#D4AF37" />
    </svg>
  );
}

export function GitaAvatar({
  size = "md",
  showOnline = true,
}: {
  size?: "sm" | "md" | "lg" | "xl";
  showOnline?: boolean;
}) {
  const sizeMap = {
    sm: { container: "w-11 h-11", halo: "w-14 h-14", dot: "w-3 h-3" },
    md: { container: "w-16 h-16", halo: "w-20 h-20", dot: "w-3.5 h-3.5" },
    lg: { container: "w-24 h-24", halo: "w-32 h-32", dot: "w-4 h-4" },
    xl: { container: "w-28 h-28", halo: "w-36 h-36", dot: "w-4 h-4" },
  }[size];

  return (
    <div className="relative inline-flex items-center justify-center shrink-0">
      <div className="absolute inset-0 flex items-center justify-center">
        <SacredYantraHalo className={sizeMap.halo} />
      </div>
      <div
        className={`relative ${sizeMap.container} rounded-full p-0.5 bg-gradient-to-tr from-[#D4AF37] via-[#E14B7B] to-[#7C2D86] shadow-md`}
      >
        <img
          src="/images/gita-avatar.png"
          alt="Gita AI – Your Favorite Astrologer"
          className="w-full h-full rounded-full object-cover object-top bg-[#FDF3EE]"
        />
        {showOnline && (
          <span
            title="Gita AI Online"
            className={`absolute bottom-0.5 right-0.5 ${sizeMap.dot} rounded-full bg-[#1E7E5A] ring-2 ring-[#FFF9F5]`}
          />
        )}
      </div>
    </div>
  );
}

export function NorthIndianKundliChart({
  houses,
  lagnaSign,
  chandraRashi,
}: {
  houses: KundliHouseData[];
  lagnaSign: string;
  chandraRashi: string;
}) {
  const getHouse = (num: number) =>
    houses.find((h) => h.houseNumber === num) || {
      houseNumber: num,
      rashiNumber: num,
      rashiName: "",
      grahas: [],
      significance: "",
    };

  // Coordinates for the 12 Bhavas in standard North Indian Diamond Kundli SVG (400x400)
  const housePositions: Array<{
    num: number;
    rashiX: number;
    rashiY: number;
    grahaX: number;
    grahaY: number;
  }> = [
    { num: 1, rashiX: 200, rashiY: 165, grahaX: 200, grahaY: 110 }, // Top center diamond (Lagna)
    { num: 2, rashiX: 100, rashiY: 75, grahaX: 100, grahaY: 42 }, // Top-left upper triangle
    { num: 3, rashiX: 65, rashiY: 110, grahaX: 38, grahaY: 100 }, // Left-top triangle
    { num: 4, rashiX: 160, rashiY: 205, grahaX: 105, grahaY: 205 }, // Left center diamond
    { num: 5, rashiX: 65, rashiY: 300, grahaX: 38, grahaY: 300 }, // Left-bottom triangle
    { num: 6, rashiX: 100, rashiY: 335, grahaX: 100, grahaY: 368 }, // Bottom-left lower triangle
    { num: 7, rashiX: 200, rashiY: 245, grahaX: 200, grahaY: 300 }, // Bottom center diamond
    { num: 8, rashiX: 300, rashiY: 335, grahaX: 300, grahaY: 368 }, // Bottom-right lower triangle
    { num: 9, rashiX: 335, rashiY: 300, grahaX: 362, grahaY: 300 }, // Right-bottom triangle
    { num: 10, rashiX: 240, rashiY: 205, grahaX: 295, grahaY: 205 }, // Right center diamond
    { num: 11, rashiX: 335, rashiY: 110, grahaX: 362, grahaY: 100 }, // Right-top triangle
    { num: 12, rashiX: 300, rashiY: 75, grahaX: 300, grahaY: 42 }, // Top-right upper triangle
  ];

  return (
    <div className="bg-gradient-to-br from-[#FFF9F5] via-[#FDF3EE] to-[#F9E6E0] border-2 border-[#D4AF37]/60 rounded-2xl p-4 shadow-sm">
      <div className="flex items-center justify-between mb-3">
        <div>
          <span className="text-[11px] font-semibold uppercase tracking-wider text-[#7C2D86] bg-[#7C2D86]/10 px-2.5 py-0.5 rounded-full">
            Lagna Kundli (North Indian Style)
          </span>
          <h4 className="text-sm font-bold text-[#2A162D] mt-1">
            Lagna: {lagnaSign} • Rashi: {chandraRashi}
          </h4>
        </div>
        <span className="text-xs font-mono-vedic text-[#B8860B] font-semibold">
          ॥ शुभ कुंडली ॥
        </span>
      </div>

      <div className="w-full max-w-[340px] mx-auto aspect-square">
        <svg
          viewBox="0 0 400 400"
          className="w-full h-full rounded-xl bg-[#FFFDFB] shadow-inner"
        >
          {/* Outer Border */}
          <rect
            x="8"
            y="8"
            width="384"
            height="384"
            rx="8"
            fill="#FFF9F5"
            stroke="#B8860B"
            strokeWidth="2.5"
          />
          {/* Inner Frame */}
          <rect
            x="14"
            y="14"
            width="372"
            height="372"
            rx="4"
            fill="none"
            stroke="#D4AF37"
            strokeWidth="1"
            opacity="0.6"
          />
          {/* Diagonal 1: Top-Left to Bottom-Right */}
          <line
            x1="14"
            y1="14"
            x2="386"
            y2="386"
            stroke="#B8860B"
            strokeWidth="1.8"
          />
          {/* Diagonal 2: Top-Right to Bottom-Left */}
          <line
            x1="386"
            y1="14"
            x2="14"
            y2="386"
            stroke="#B8860B"
            strokeWidth="1.8"
          />
          {/* Inner Diamond connecting Midpoints */}
          <polygon
            points="200,14 386,200 200,386 14,200"
            fill="none"
            stroke="#7C2D86"
            strokeWidth="1.8"
          />

          {/* Render House Numbers (Rashi numbers) & Graha labels */}
          {housePositions.map((pos) => {
            const h = getHouse(pos.num);
            const shortGrahas = h.grahas.map((g) => g.split(" ")[0]).join(" ");
            return (
              <g key={pos.num}>
                {/* Rashi Number in subtle gold */}
                <text
                  x={pos.rashiX}
                  y={pos.rashiY}
                  textAnchor="middle"
                  className="text-[11px] font-mono-vedic fill-[#B8860B] font-bold"
                >
                  {h.rashiNumber}
                </text>
                {/* Graha Abbreviations */}
                {shortGrahas && (
                  <text
                    x={pos.grahaX}
                    y={pos.grahaY}
                    textAnchor="middle"
                    className="text-[11px] font-bold fill-[#2A162D]"
                  >
                    {shortGrahas}
                  </text>
                )}
              </g>
            );
          })}
        </svg>
      </div>

      <div className="mt-3 grid grid-cols-3 gap-1.5 text-[11px] text-[#6E5273] bg-white/80 p-2.5 rounded-xl border border-[#EFE1E6]">
        <div>
          <strong className="text-[#2A162D]">Su:</strong> Surya
        </div>
        <div>
          <strong className="text-[#2A162D]">Ch:</strong> Chandra
        </div>
        <div>
          <strong className="text-[#2A162D]">Ma:</strong> Mangal
        </div>
        <div>
          <strong className="text-[#2A162D]">Bu:</strong> Budh
        </div>
        <div>
          <strong className="text-[#2A162D]">Gu:</strong> Guru
        </div>
        <div>
          <strong className="text-[#2A162D]">Sk:</strong> Shukra
        </div>
        <div>
          <strong className="text-[#2A162D]">Sa:</strong> Shani
        </div>
        <div>
          <strong className="text-[#2A162D]">Ra:</strong> Rahu
        </div>
        <div>
          <strong className="text-[#2A162D]">Ke:</strong> Ketu
        </div>
      </div>
    </div>
  );
}
