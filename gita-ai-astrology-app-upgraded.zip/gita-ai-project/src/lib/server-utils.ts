import crypto from "crypto";
import { db } from "@/db";
import {
  users,
  dailyHoroscopes,
  appConfig,
  remedies,
  chatMessages,
  payments,
  auditLogs,
  kundliReadings,
} from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  TWELVE_RASHIS,
  DEFAULT_REMEDIES,
  calculateVedicKundli,
} from "./astrology";

const AUTH_SECRET =
  process.env.AUTH_SECRET || "gita-ai-luminous-vedic-sanctuary-secret-2026";

export function hashPassword(password: string): string {
  return crypto
    .createHmac("sha256", AUTH_SECRET)
    .update(password)
    .digest("hex");
}

export function createSessionToken(userId: number, role: string): string {
  const payload = JSON.stringify({
    uid: userId,
    role,
    iat: Date.now(),
  });
  const base64Payload = Buffer.from(payload).toString("base64url");
  const signature = crypto
    .createHmac("sha256", AUTH_SECRET)
    .update(base64Payload)
    .digest("base64url");
  return `${base64Payload}.${signature}`;
}

export function verifySessionToken(
  token?: string | null
): { uid: number; role: string } | null {
  if (!token || !token.includes(".")) return null;
  const [base64Payload, signature] = token.split(".");
  if (!base64Payload || !signature) return null;
  const expectedSig = crypto
    .createHmac("sha256", AUTH_SECRET)
    .update(base64Payload)
    .digest("base64url");
  if (signature !== expectedSig) return null;
  try {
    const parsed = JSON.parse(
      Buffer.from(base64Payload, "base64url").toString("utf-8")
    );
    if (typeof parsed.uid === "number") {
      return { uid: parsed.uid, role: parsed.role || "user" };
    }
    return null;
  } catch {
    return null;
  }
}

export function computeEntitlement(user: typeof users.$inferSelect) {
  const now = Date.now();
  const isSubscribed =
    user.subscriptionStatus === "active" &&
    (!user.subscriptionExpiresAt ||
      new Date(user.subscriptionExpiresAt).getTime() > now);

  let trialActive = false;
  let remainingTrialSeconds = 0;
  let trialExpired = false;

  if (!user.trialStartedAt && !user.trialUsed) {
    // Eligible new user who hasn't started their 15s free trial yet
    remainingTrialSeconds = 15;
    trialActive = false;
    trialExpired = false;
  } else if (user.trialStartedAt) {
    const elapsedSeconds = Math.floor(
      (now - new Date(user.trialStartedAt).getTime()) / 1000
    );
    remainingTrialSeconds = Math.max(0, 15 - elapsedSeconds);
    trialActive = remainingTrialSeconds > 0;
    trialExpired = remainingTrialSeconds <= 0 && !isSubscribed;
  } else if (user.trialUsed && !isSubscribed) {
    remainingTrialSeconds = 0;
    trialActive = false;
    trialExpired = true;
  }

  const canChat =
    isSubscribed || (!user.trialStartedAt && !user.trialUsed) || trialActive;

  return {
    isSubscribed,
    trialEligible: !user.trialStartedAt && !user.trialUsed,
    trialActive,
    trialExpired,
    remainingTrialSeconds,
    canChat,
    subscriptionStatus: isSubscribed
      ? "active"
      : trialActive
      ? "trial"
      : trialExpired && user.subscriptionStatus === "trial"
      ? "expired"
      : user.subscriptionStatus,
  };
}

let isSeeded = false;

export async function ensureSeeded() {
  if (isSeeded) return;
  try {
    // 1. Seed 12 Daily Horoscopes if empty
    const existingHoroscopes = await db.select().from(dailyHoroscopes);
    if (existingHoroscopes.length === 0) {
      for (const r of TWELVE_RASHIS) {
        await db
          .insert(dailyHoroscopes)
          .values({
            rashi: r.rashi,
            rashiHindi: r.rashiHindi,
            symbol: r.symbol,
            element: r.element,
            rulingPlanet: r.rulingPlanet,
            dailyForecastHinglish: r.dailyForecastHinglish,
            dailyForecastHindi: r.dailyForecastHindi,
            dailyForecastEnglish: r.dailyForecastEnglish,
            luckyColor: r.luckyColor,
            luckyColorHex: r.luckyColorHex,
            luckyNumber: r.luckyNumber,
            dailyReflection: r.dailyReflection,
            positiveHabit: r.positiveHabit,
          })
          .onConflictDoNothing();
      }
    }

    // 2. Seed App Config
    const existingConfig = await db.select().from(appConfig);
    if (existingConfig.length === 0) {
      const defaults = [
        {
          key: "welcome_message",
          value: "Namaste! Main Gita hoon. Aaj aap kya jaana chahte hain?",
        },
        { key: "subscription_price_inr", value: "49" },
        { key: "trial_duration_seconds", value: "15" },
        {
          key: "daily_astrologer_note",
          value:
            "Aaj शुक्ल पक्ष ki sakaratmak urja hai. Shant man se liya gaya sankalp aapko safalta aur manah-shanti dega.",
        },
        {
          key: "astrology_disclaimer",
          value:
            "Astrology is for entertainment and personal reflection, not guaranteed prediction or professional medical, legal, or financial advice.",
        },
      ];
      for (const item of defaults) {
        await db.insert(appConfig).values(item).onConflictDoNothing();
      }
    }

    // 3. Seed Default Users (Eligible New User, Premium User, and Admin)
    const existingUsers = await db.select().from(users);
    if (existingUsers.length === 0) {
      // Eligible New User (15s trial ready to start on first chat!)
      const [aarav] = await db
        .insert(users)
        .values({
          email: "aarav@gita-ai.in",
          phone: "+91 98765 43210",
          passwordHash: hashPassword("Gita@123"),
          name: "Aarav Sharma",
          role: "user",
          preferredLanguage: "hinglish",
          birthDate: "1997-08-19",
          birthTime: "09:30",
          birthPlace: "Jaipur, Rajasthan",
          rashi: "Kumbha (Aquarius)",
          nakshatra: "Dhanishta",
          consentGiven: true,
          notificationsEnabled: true,
          reminderTime: "08:00",
          trialStartedAt: null,
          trialUsed: false,
          subscriptionStatus: "none",
          subscriptionPlan: "monthly_49",
        })
        .returning();

      // Seed welcome message & remedies for Aarav
      if (aarav) {
        await db.insert(chatMessages).values({
          userId: aarav.id,
          sessionId: "welcome-session",
          topic: "Personal Guidance",
          role: "assistant",
          content:
            "Namaste Aarav ji! 🙏 Main Gita hoon — aapki priya jyotish margdarshak. Aaj aap apne Career, Love, Marriage, Kundli ya kisi bhi vishay par kya jaana chahte hain? Aapka 15-second free trial aapke pehle sawal bhejte hi shuru hoga!",
          isSavedReading: true,
        });

        for (const rem of DEFAULT_REMEDIES) {
          await db.insert(remedies).values({
            userId: aarav.id,
            title: rem.title,
            category: rem.category,
            description: rem.description,
            mantraOrAction: rem.mantraOrAction,
            isCompleted: false,
            streakCount: 1,
          });
        }

        const initialKundli = calculateVedicKundli({
          name: aarav.name,
          birthDate: "1997-08-19",
          birthTime: "09:30",
          birthPlace: "Jaipur, Rajasthan",
        });

        await db.insert(kundliReadings).values({
          userId: aarav.id,
          name: aarav.name,
          birthDate: "1997-08-19",
          birthTime: "09:30",
          birthPlace: "Jaipur, Rajasthan",
          calculationMode: initialKundli.calculationMode,
          lagnaSign: initialKundli.lagnaSign,
          chandraRashi: initialKundli.chandraRashi,
          suryaRashi: initialKundli.suryaRashi,
          nakshatra: initialKundli.nakshatra,
          planetaryPositions: JSON.stringify(initialKundli.houses),
          aiInterpretation: initialKundli.summaryHinglish,
        });
      }

      // Trial-Expired User (Requires verified ₹49 payment to 7250595155@ibl to unlock Premium)
      const [priya] = await db
        .insert(users)
        .values({
          email: "priya@gita-ai.in",
          phone: "+91 98201 11223",
          passwordHash: hashPassword("Gita@123"),
          name: "Priya Verma",
          role: "user",
          preferredLanguage: "hinglish",
          birthDate: "1999-03-24",
          birthTime: "14:15",
          birthPlace: "Mumbai, Maharashtra",
          rashi: "Vrishabha (Taurus)",
          nakshatra: "Rohini",
          consentGiven: true,
          notificationsEnabled: true,
          trialStartedAt: new Date(Date.now() - 86400000),
          trialUsed: true,
          subscriptionStatus: "pending",
          subscriptionPlan: "monthly_49",
          subscriptionExpiresAt: null,
        })
        .returning();

      if (priya) {
        await db.insert(payments).values({
          userId: priya.id,
          orderId: "GITA_ORD_3_PENDING_1001",
          recipientUpiId: "7250595155@ibl",
          provider: "phonepe",
          amountInr: 49,
          status: "pending",
          verificationMethod: "verification_unavailable_missing_merchant_api",
          failureReason:
            "Waiting for independent server-side payment verification for 7250595155@ibl.",
        });
      }

      // Admin User
      const [adminUser] = await db
        .insert(users)
        .values({
          email: "admin@gita-ai.in",
          phone: "+91 99000 00001",
          passwordHash: hashPassword("Admin@123"),
          name: "Acharya Admin",
          role: "admin",
          preferredLanguage: "english",
          birthDate: "1990-11-11",
          birthTime: "06:30",
          birthPlace: "Varanasi, Uttar Pradesh",
          rashi: "Simha (Leo)",
          nakshatra: "Magha",
          consentGiven: true,
          trialUsed: true,
          subscriptionStatus: "expired",
          subscriptionPlan: "monthly_49",
          subscriptionExpiresAt: null,
        })
        .returning();

      if (adminUser && priya) {
        await db.insert(auditLogs).values([
          {
            actorUserId: priya.id,
            targetUserId: priya.id,
            eventType: "UPI_ORDER_PENDING_VERIFICATION",
            details: JSON.stringify({
              orderId: "GITA_ORD_3_PENDING_1001",
              recipientUpiId: "7250595155@ibl",
              amountInr: 49,
              provider: "phonepe",
              status: "pending",
            }),
          },
          {
            actorUserId: adminUser.id,
            targetUserId: null,
            eventType: "SYSTEM_INITIALIZED",
            details: JSON.stringify({
              message:
                "Gita AI database initialized with 12 Rashis, RBAC admin, and strict 7250595155@ibl UPI verification enforcement.",
            }),
          },
        ]);
      }
    }

    isSeeded = true;
  } catch (err) {
    console.error("[GitaAI] Seed check error:", err);
  }
}

export async function getUserFromRequestHeaders(headers: Headers) {
  await ensureSeeded();
  const authHeader = headers.get("authorization");
  const token = authHeader?.startsWith("Bearer ")
    ? authHeader.slice(7).trim()
    : headers.get("x-gita-token");

  const verified = verifySessionToken(token);
  if (verified) {
    const [found] = await db
      .select()
      .from(users)
      .where(eq(users.id, verified.uid));
    if (found) return found;
  }

  return null;
}
