import { calculateVedicKundli } from "./astrology";

export interface GitaChatContext {
  userName: string;
  preferredLanguage: "hinglish" | "hindi" | "english";
  birthDate?: string | null;
  birthTime?: string | null;
  birthPlace?: string | null;
  rashi?: string | null;
  nakshatra?: string | null;
  topic: string;
  userMessage: string;
  history: Array<{ role: string; content: string }>;
}

const SYSTEM_PROMPT = `You are Gita AI, a senior Indian female Vedic Jyotish Acharya. Speak with the clarity, composure, warmth, and practical judgment of a learned traditional pandit. Address the user as Ji / Aap and use their preferred language: natural Roman-script Hinglish, clear Devanagari Hindi, or culturally rooted English.

Jyotish method and vocabulary:
- Draw on the classical spirit of Bṛhat Parāśara Horā Śāstra, Phaladīpikā, and Bṛhat Jātaka. Use Lagna, the twelve bhavas, Navagraha, Nakshatra, graha lords, dasha, and gochar naturally when relevant.
- For vivah, assess the Saptam Bhava and its lord, Shukra as vivah-karaka, Guru, Navamsha, and relevant dasha/transit periods. For career, discuss the Dasham Bhava and its lord, Karma, and relevant supporting houses. Make answers specific to the question rather than giving a generic horoscope.
- For upay, suggest modest mantras, puja, daan, colours, or helpful habits. Never pressure the user to buy gemstones or expensive rituals.
- When numerology is requested, give only a basic traditional ank reading derived from the birth date or name supplied.
- When Panchang or muhurat matters, distinguish tithi, vara, nakshatra, yoga, karana, and local muhurat. Do not invent today's Panchang, exact dasha dates, planetary placements, or a wedding date if the available profile/calculation does not establish them.
- Use the user's saved or supplied birth details. The profile included below is the source of truth; do not ask again for details already present. Do not infer missing birth data, chart placements, or relationship facts.
- No palm-image vision is available unless an image-analysis result is explicitly provided in context. Never claim to see a palm photo or invent line/mount details. If asked to read an image without vision data, say so politely and invite a description of the visible lines.

Reply style:
- Be confident, clear, kind, useful, and culturally grounded. Explain the Jyotish reasoning briefly and give a concrete next step or simple upay.
- Do not append disclaimers, end notes, reminders, or weak language such as “for entertainment,” “personal reflection only,” or “not scientifically guaranteed.” Do not end with an unsolicited disclaimer.
- Do not promise certainty or use fear, curses, or coercion. If an exact calculation is not available, state the specific missing calculation plainly and offer the closest honest guidance without fabricating a result.`;

type Kundli = ReturnType<typeof calculateVedicKundli>;

export async function generateGitaResponse(
  ctx: GitaChatContext
): Promise<{ reply: string; engineUsed: string }> {
  const openAiKey = process.env.OPENAI_API_KEY;
  const geminiKey = process.env.GEMINI_API_KEY;

  const birthDate =
    normalizeBirthDate(ctx.birthDate) || extractBirthDate(ctx.userMessage);
  const kundli = birthDate
    ? calculateVedicKundli({
        name: ctx.userName,
        birthDate,
        birthTime: ctx.birthTime,
        birthPlace: ctx.birthPlace,
      })
    : null;

  // Mesh/Ashwini are database defaults, not necessarily user-provided chart facts.
  const isUnconfirmedDefault =
    !birthDate &&
    ctx.rashi === "Mesh (Aries)" &&
    ctx.nakshatra === "Ashwini";
  const effectiveRashi =
    kundli?.chandraRashi || (isUnconfirmedDefault ? null : ctx.rashi || null);
  const effectiveNakshatra =
    kundli?.nakshatra ||
    (isUnconfirmedDefault ? null : ctx.nakshatra || null);
  const userProfileSummary = [
    `User name: ${ctx.userName}`,
    `Preferred language: ${ctx.preferredLanguage}`,
    `Current topic: ${ctx.topic}`,
    `Birth date: ${birthDate || "not provided"}`,
    `Birth time: ${ctx.birthTime || "not provided"}`,
    `Birth place: ${ctx.birthPlace || "not provided"}`,
    `Saved Chandra Rashi: ${effectiveRashi || "not provided"}`,
    `Saved Nakshatra: ${effectiveNakshatra || "not provided"}`,
    kundli
      ? `Built-in chart estimate: Lagna ${kundli.lagnaSign}, Surya Rashi ${kundli.suryaRashi}, Chandra Rashi ${kundli.chandraRashi}, Nakshatra ${kundli.nakshatra}. The current calculator is approximate and does not calculate exact Vimshottari dasha, Navamsha, Panchang, or location-based planetary positions.`
      : "",
  ]
    .filter(Boolean)
    .join("\n");

  const replyContext: ReplyContext = {
    ...ctx,
    birthDate,
    effectiveRashi,
    effectiveNakshatra,
    kundli,
  };

  // Provider keys are read only on the server. Provider failures fall through
  // to the built-in engine so a missing key or outage never breaks chat.
  if (openAiKey && openAiKey.trim().length > 10) {
    try {
      const messages = [
        {
          role: "system",
          content: `${SYSTEM_PROMPT}\n\nUSER'S SAVED ASTROLOGICAL PROFILE:\n${userProfileSummary}`,
        },
        ...ctx.history.slice(-8).map((message) => ({
          role: message.role === "assistant" ? "assistant" : "user",
          content: message.content,
        })),
        { role: "user", content: ctx.userMessage },
      ];

      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${openAiKey}`,
        },
        body: JSON.stringify({
          model: process.env.OPENAI_MODEL || "gpt-4o-mini",
          messages,
          temperature: 0.7,
          max_tokens: 650,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const text = data.choices?.[0]?.message?.content?.trim();
        if (text) return { reply: text, engineUsed: "openai_llm" };
      }
    } catch {
      console.error("[GitaAI] OpenAI request failed; using the next available engine.");
    }
  }

  if (geminiKey && geminiKey.trim().length > 10) {
    try {
      const promptText = `${SYSTEM_PROMPT}\n\nUSER'S SAVED ASTROLOGICAL PROFILE:\n${userProfileSummary}\n\nCONVERSATION HISTORY:\n${ctx.history
        .slice(-6)
        .map((message) => `${message.role.toUpperCase()}: ${message.content}`)
        .join("\n")}\n\nUSER QUESTION: ${ctx.userMessage}\n\nGITA AI RESPONSE:`;

      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${geminiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ parts: [{ text: promptText }] }],
          }),
        }
      );

      if (response.ok) {
        const data = await response.json();
        const text = data.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
        if (text) return { reply: text, engineUsed: "gemini_llm" };
      }
    } catch {
      // Avoid logging the provider URL, which contains the server-side key.
      console.error("[GitaAI] Gemini request failed; using the built-in engine.");
    }
  }

  return {
    reply: buildContextualVedicReply(replyContext),
    engineUsed: "vedic_contextual_ai",
  };
}

interface ReplyContext extends GitaChatContext {
  birthDate: string | null;
  effectiveRashi: string | null;
  effectiveNakshatra: string | null;
  kundli: Kundli | null;
}

function buildContextualVedicReply(context: ReplyContext): string {
  const {
    userName,
    preferredLanguage,
    birthDate,
    topic,
    userMessage,
    effectiveRashi,
    effectiveNakshatra,
    kundli,
  } = context;
  const text = `${topic} ${userMessage}`.toLowerCase();

  const isPalmistry =
    /palm|palmistry|hast.?rekha|haath ki rekha|हस्तरेखा|हथेली|हाथ की रेखा/.test(
      text
    );
  const isNumerology =
    /numerolog|\bank\b|moolank|mulank|bhagyank|naamank|number meaning|अंक|मूलांक|भाग्यांक|नामांक/.test(
      text
    );
  const isPanchang =
    /panchang|muhurat|muhurta|tithi|karan|yog|पंचांग|मुहूर्त|तिथि|करण|योग/.test(
      text
    );
  const isMarriage =
    /marriage|shaadi|vivah|spouse|husband|wife|life partner|kundli milan|विवाह|शादी|जीवनसाथी/.test(
      text
    );
  const isLove =
    /love|pyaar|relationship|partner|breakup|rishta|prem|प्यार|प्रेम|रिश्ता|संबंध/.test(
      text
    );
  const isCareer =
    /career|job|naukri|promotion|business|kaam|interview|करियर|नौकरी|काम|व्यवसाय/.test(
      text
    );
  const isMoney =
    /money|paisa|dhan|finance|wealth|loan|savings|धन|पैसा|आर्थिक|बचत/.test(text);
  const isFamily =
    /family|parivar|parents|ghar|shanti|परिवार|माता|पिता|घर|शांति/.test(text);
  const isKundli =
    /kundli|janam patrika|birth chart|rashi|nakshatra|lagna|कुंडली|जन्मपत्रिका|राशि|नक्षत्र|लग्न/.test(
      text
    );
  const isRemedy =
    /upay|remedy|mantra|puja|pooja|daan|उपाय|मंत्र|पूजा|दान/.test(text);
  const greeting =
    preferredLanguage === "hindi"
      ? `नमस्ते ${userName} जी।`
      : preferredLanguage === "english"
        ? `Namaste ${userName} ji.`
        : `Namaste ${userName} ji.`;

  const personalContext =
    birthDate && kundli
      ? preferredLanguage === "hindi"
        ? `आपकी सहेजी हुई जन्म-तिथि ${birthDate} से उपलब्ध प्रारंभिक गणना में चंद्र राशि **${kundli.chandraRashi}** और नक्षत्र **${kundli.nakshatra}** आते हैं। जन्म-समय और स्थान दर्ज हैं, पर यह गणना उनसे सटीक लग्न या ग्रह-स्थिति सत्यापित नहीं करती।`
        : preferredLanguage === "english"
          ? `Using your saved birth date ${birthDate}, the built-in preliminary estimate gives **${kundli.chandraRashi}** Chandra Rashi and **${kundli.nakshatra}** Nakshatra. Your time and place are recorded, but this calculation does not verify exact Lagna or planetary positions from them.`
          : `Aapki saved janm-tithi ${birthDate} se built-in prarambhik ganana mein **${kundli.chandraRashi}** Chandra Rashi aur **${kundli.nakshatra}** Nakshatra milte hain. Samay aur sthan darj hain, lekin yeh ganana inse exact Lagna ya graha-sthiti verify nahi karti.`
      : effectiveRashi || effectiveNakshatra
        ? preferredLanguage === "hindi"
          ? `आपकी प्रोफ़ाइल में ${effectiveRashi ? `**${effectiveRashi}** राशि` : ""}${effectiveRashi && effectiveNakshatra ? " और " : ""}${effectiveNakshatra ? `**${effectiveNakshatra}** नक्षत्र` : ""} दर्ज है।`
          : preferredLanguage === "english"
            ? `Your profile records ${effectiveRashi ? `**${effectiveRashi}** Rashi` : ""}${effectiveRashi && effectiveNakshatra ? " and " : ""}${effectiveNakshatra ? `**${effectiveNakshatra}** Nakshatra` : ""}.`
            : `Aapki profile mein ${effectiveRashi ? `**${effectiveRashi}** rashi` : ""}${effectiveRashi && effectiveNakshatra ? " aur " : ""}${effectiveNakshatra ? `**${effectiveNakshatra}** nakshatra` : ""} darj hai.`
        : preferredLanguage === "hindi"
          ? "आपकी जन्म-तिथि अभी प्रोफ़ाइल में नहीं है; इसलिए मैं कोई राशि या नक्षत्र मानकर नहीं चलूँगी।"
          : preferredLanguage === "english"
            ? "Your birth date is not in the profile, so I will not assume a Rashi or Nakshatra."
            : "Aapki janm-tithi profile mein abhi nahi hai, isliye main koi rashi ya nakshatra maan kar nahi chalungi.";

  if (isPalmistry) {
    if (preferredLanguage === "hindi") {
      return `${greeting} इस बातचीत में हथेली की तस्वीर देखने की सुविधा उपलब्ध नहीं है, इसलिए मैं रेखाओं के बारे में अनुमान नहीं लगाऊँगी। आप जीवन रेखा, मस्तिष्क रेखा, हृदय रेखा और भाग्य रेखा की लंबाई, निरंतरता, शाखाओं या टूटन का वर्णन करें; मैं केवल आपके बताए दृश्य संकेतों के आधार पर पारंपरिक हस्तरेखा-विचार दूँगी। फोटो-पठन के लिए vision सुविधा को अलग से जोड़ना होगा।`;
    }
    if (preferredLanguage === "english") {
      return `${greeting} Palm-image vision is not available in this chat, so I will not invent line or mount details. Describe the visible Jeevan (life), Mastishk (head), Hriday (heart), and Bhagya (fate) lines—their length, continuity, branches, or breaks—and I can interpret only what you describe. Photo reading needs vision capability to be configured.`;
    }
    return `${greeting} Is chat mein palm-image vision abhi available nahi hai, isliye main rekhaon ke baare mein kuchh gadhungi nahi. Aap Jeevan, Mastishk, Hriday aur Bhagya rekha ki lambai, continuity, shaakha ya tootne ka varnan karein; main sirf aapke bataye drishya sanketon par paramparik hastrekha-vichar doongi. Photo reading ke liye vision configuration chahiye.`;
  }

  if (isNumerology) {
    return buildNumerologyReply({
      userName,
      preferredLanguage,
      birthDate,
      userMessage,
    });
  }

  if (isPanchang) {
    if (preferredLanguage === "hindi") {
      return `${greeting} पंचांग-विचार में तिथि, वार, नक्षत्र, योग, करण और स्थान के अनुसार लग्न/स्थानीय मुहूर्त देखा जाता है। विवाह या किसी शुभ कार्य का मुहूर्त पूछ रहे हों तो तारीख़ या तारीख़ों की सीमा और शहर बताइए। इस ऐप का वर्तमान गणना-इंजन सत्यापित स्थानीय पंचांग नहीं निकालता, इसलिए मैं तिथि या शुभ समय गढ़कर नहीं बताऊँगी।`;
    }
    if (preferredLanguage === "english") {
      return `${greeting} A proper Panchang reading weighs tithi, weekday (vara), Nakshatra, yoga, karana, and the local Lagna/muhurta. If you want a wedding or event muhurta, share the date or date range and city. This app's current calculator does not produce a verified local Panchang, so I will not invent a tithi or auspicious time.`;
    }
    return `${greeting} Panchang mein tithi, vaar, nakshatra, yoga, karan aur sthan ke anusaar lagna/local muhurat dekha jata hai. Shaadi ya kisi shubh karya ka muhurat chahiye toh tareekh ya date range aur shehar batayein. App ka abhi ka calculator verified local Panchang nahi nikalta, isliye main tithi ya shubh samay gadhkar nahi bataungi.`;
  }

  if (isRemedy) {
    if (isMarriage) {
      if (preferredLanguage === "hindi") {
        return `${greeting} ${personalContext}\n\nविवाह-विचार में सरल उपाय के रूप में शुक्रवार को “ॐ शुं शुक्राय नमः” 11 बार शांत मन से जपें और संभव हो तो किसी ज़रूरतमंद को मीठा या सफेद अन्न दें। रत्न या महँगे अनुष्ठान आवश्यक नहीं हैं।`;
      }
      if (preferredLanguage === "english") {
        return `${greeting} ${personalContext}\n\nFor marriage-related upay, recite “Om Shum Shukraya Namah” 11 times calmly on Friday and, if possible, offer sweets or white grains to someone in need. Expensive gemstones or rituals are not necessary.`;
      }
      return `${greeting} ${personalContext}\n\nVivah se jude saral upay ke liye Shukravar ko “Om Shum Shukraya Namah” shaant man se 11 baar jap karein aur sambhav ho toh kisi zarooratmand ko meetha ya safed ann dein. Mahange ratna ya anushthan zaroori nahi.`;
    }
    if (preferredLanguage === "hindi") {
      return `${greeting} ${personalContext}\n\nसरल उपाय के रूप में प्रतिदिन शांत मन से अपने इष्ट-मंत्र का 11 बार जप करें; शुक्रवार को मीठा या सफेद अन्न किसी ज़रूरतमंद को देना भी सहज दान है। रत्न या महँगे अनुष्ठान आवश्यक नहीं हैं।`;
    }
    if (preferredLanguage === "english") {
      return `${greeting} ${personalContext}\n\nA simple upay: recite a prayer or mantra meaningful to you 11 times with a steady mind, and offer a modest food donation to someone in need on Friday. Expensive gemstones or rituals are not necessary.`;
    }
    return `${greeting} ${personalContext}\n\nSaral upay ke roop mein apne isht-mantra ka shaant man se 11 baar jap karein; Shukravar ko meetha ya safed ann kisi zarooratmand ko dena bhi saral daan hai. Mahange ratna ya anushthan zaroori nahi.`;
  }

  if (isMarriage) {
    if (preferredLanguage === "hindi") {
      return `${greeting} ${personalContext}\n\n**विवाह-विचार:** पाराशरी पद्धति में सप्तम भाव, सप्तमेश, शुक्र, गुरु और नवांश को साथ देखकर विवाह-योग समझा जाता है। समय के लिए संबंधित महादशा/अंतर्दशा, 2–7–11 भावों के संबंध और गुरु-शनि के गोचर भी मिलाए जाते हैं।\n\nआपके प्रश्न का सीधा उत्तर: इस ऐप की प्रारंभिक गणना अभी सटीक विम्शोत्तरी दशा, नवांश या स्थान-आधारित गोचर नहीं निकालती, इसलिए मैं विवाह का वर्ष या तारीख़ बनाकर नहीं बताऊँगी। आप अपना जन्म-समय और जन्म-स्थान साझा करें—यदि ये पहले से प्रोफ़ाइल में हैं तो दोबारा भेजने की ज़रूरत नहीं—और मैं उपलब्ध कुंडली-संकेतों के अनुसार समझाऊँगी कि किन योगों और अवधियों की जाँच आवश्यक है।`;
    }
    if (preferredLanguage === "english") {
      return `${greeting} ${personalContext}\n\n**Marriage in classical Jyotish:** Parāśari assessment reads the Seventh Bhava and its lord alongside Shukra, Guru, and the Navamsha. Timing is judged from relevant mahadasha/antardasha periods, links to houses 2, 7, and 11, and supporting Guru–Shani gochara.\n\nFor your question, the current built-in calculation does not produce exact Vimshottari dasha, Navamsha, or location-based transits, so I will not manufacture a marriage year or date. Share your birth time and birthplace if they are not already saved; I can then explain which chart factors and periods need to be examined.`;
    }
    return `${greeting} ${personalContext}\n\n**Vivah ka shastriya vichar:** Parāśari paddhati mein Saptam Bhava aur Saptamesh ke saath Shukra, Guru aur Navamsha ko dekhkar vivah-yog samjha jata hai. Samay ke liye sambandhit mahadasha/antardasha, 2–7–11 bhavon ke sambandh aur Guru–Shani gochar ko bhi milaya jata hai.\n\nAapke sawal ka seedha uttar: app ki prarambhik ganana abhi exact Vimshottari dasha, Navamsha ya location-based gochar nahi nikalti, isliye main shaadi ka saal ya tareekh gadhkar nahi bataungi. Janm-samay aur sthan profile mein pehle se na hon tab share karein; phir main bataungi ki kundli ke kin yogon aur avadhiyon ko dekhna hoga.`;
  }

  if (isLove) {
    if (preferredLanguage === "hindi") {
      return `${greeting} ${personalContext}\n\nपारंपरिक ज्योतिष में प्रेम और संबंधों के लिए पंचम भाव (आकर्षण/प्रेम), सप्तम भाव (प्रतिबद्धता), शुक्र और चंद्रमा के संकेत देखे जाते हैं; विवाह की दिशा समझने में सप्तमेश और गुरु भी महत्त्व रखते हैं। इस समय आपके लिए सबसे उपयोगी कदम है कि अपनी अपेक्षाएँ साफ़ कहें और सामने वाले के व्यवहार में निरंतरता देखें। किसी विशेष रिश्ते पर कुंडली-विचार चाहिए तो दूसरे व्यक्ति की जन्म-तिथि, समय और स्थान भी दें।`;
    }
    if (preferredLanguage === "english") {
      return `${greeting} ${personalContext}\n\nTraditional Jyotish considers the Fifth Bhava for affection, the Seventh for commitment, and the condition of Shukra and Chandra; the Seventh lord and Guru add context when marriage is the question. For this relationship, make your expectations explicit and judge the bond by consistent actions, not one intense conversation. For a two-chart reading, share the other person's birth details as well.`;
    }
    return `${greeting} ${personalContext}\n\nParamparik Jyotish mein prem ke liye Pancham Bhava, pratibaddh sambandh ke liye Saptam Bhava, aur Shukra-Chandra ke sanket dekhe jate hain; vivah-vichar mein Saptamesh aur Guru bhi mahatvapurn hain. Is rishte mein apni apekshaen saaf rakhein aur saamne wale ke vyavahar ki nirantarata dekhein. Dono ki kundli ka milan chahiye toh doosre vyakti ki janm-tithi, samay aur sthan bhi share karein.`;
  }

  if (isCareer) {
    if (preferredLanguage === "hindi") {
      return `${greeting} ${personalContext}\n\n**कर्म और करियर:** दशम भाव तथा दशमेश कर्म-दिशा बताते हैं; द्वितीय, षष्ठ और एकादश भाव आजीविका, सेवा और लाभ के संदर्भ देते हैं। किसी बदलाव का समय देखने में संबंधित ग्रहों की दशा और गोचर मिलाए जाते हैं। अभी अपने कौशल और उपलब्धियों का स्पष्ट लेखा रखें, फिर निर्णय को वास्तविक अवसर और जिम्मेदारी के आधार पर तौलें। सटीक करियर-समय के लिए इस ऐप में दशा और सत्यापित गोचर-गणना अभी उपलब्ध नहीं है।`;
    }
    if (preferredLanguage === "english") {
      return `${greeting} ${personalContext}\n\n**Karma and career:** The Tenth Bhava and its lord describe professional direction; the Second, Sixth, and Eleventh add livelihood, service, and gains. Classical timing also checks the relevant dasha and gochara. For your next move, document your skills and results, then compare the real opportunity, responsibility, and stability before deciding. Exact career timing is not calculated by the current built-in dasha/transit engine.`;
    }
    return `${greeting} ${personalContext}\n\n**Karma aur career:** Dasham Bhava aur Dashamesh karma ki disha batate hain; Dvitiya, Shashth aur Ekadash Bhava aajeevika, seva aur labh ka sandarbh dete hain. Badlav ka samay dekhne ke liye sambandhit grahon ki dasha aur gochar milaye jate hain. Abhi apne kaushal aur uplabdhiyon ka saaf hisaab rakhein, phir naye avsar ki zimmedari aur sthirta ko dekhkar nirnay lein. App ka built-in engine exact dasha/gochar se career timing nahi nikalta.`;
  }

  if (isMoney) {
    if (preferredLanguage === "hindi") {
      return `${greeting} ${personalContext}\n\nधन-विचार में द्वितीय भाव (संचित धन), एकादश भाव (आय/लाभ), पंचम और नवम भाव के साथ उनके स्वामियों की स्थिति देखी जाती है। ज्योतिषीय संकेत को व्यवहार में बदलने के लिए इस महीने की आय, आवश्यक खर्च और बचत अलग-अलग लिखें; बिना हिसाब के बड़ा जोखिम न लें। किसी विशेष आर्थिक अवधि का ज्योतिषीय आकलन करने के लिए सटीक दशा-गणना भी चाहिए, जो इस ऐप में अभी उपलब्ध नहीं है।`;
    }
    if (preferredLanguage === "english") {
      return `${greeting} ${personalContext}\n\nA classical wealth reading considers the Second Bhava for accumulated resources, the Eleventh for income and gains, and supporting links to the Fifth and Ninth. A useful step now is to separate this month's income, essential spending, and savings before taking on a large commitment. The current app does not calculate exact dasha periods for financial timing.`;
    }
    return `${greeting} ${personalContext}\n\nDhan-vichar mein Dvitiya Bhava (sanchit dhan), Ekadash Bhava (aay/labh), aur Pancham-Navam Bhava ke sambandh dekhe jate hain. Is sanket ko amal mein lane ke liye is mahine ki aay, zaroori kharch aur bachat alag likhein; bina hisaab bada jokhim na lein. App abhi exact dasha-aadharit arthik timing nahi nikalta.`;
  }

  if (isFamily) {
    if (preferredLanguage === "hindi") {
      return `${greeting} ${personalContext}\n\nपरिवार और गृह-सुख के लिए चतुर्थ भाव, चंद्रमा और उनसे जुड़े ग्रह देखे जाते हैं; परिवार की वाणी और संसाधनों में द्वितीय भाव भी संदर्भ देता है। आज किसी एक लंबित बात को शांत समय में उठाएँ, पहले पूरी बात सुनें और फिर अपना पक्ष स्पष्ट रखें।`;
    }
    if (preferredLanguage === "english") {
      return `${greeting} ${personalContext}\n\nFor home and family matters, Jyotish considers the Fourth Bhava and Chandra; the Second Bhava can add context around family speech and shared resources. Choose one unresolved matter, discuss it at a calm time, listen fully, and then state your position clearly.`;
    }
    return `${greeting} ${personalContext}\n\nGhar-parivar ke liye Chaturth Bhava aur Chandra dekhe jate hain; parivarik vaani aur saajhe sansadhanon mein Dvitiya Bhava bhi sandarbh deta hai. Aaj ek pending baat shant samay par uthayein, pehle poori baat sunein, phir apna paksh saaf rakhein.`;
  }

  if (isKundli) {
    if (preferredLanguage === "hindi") {
      return `${greeting} ${personalContext}\n\nकुंडली-विचार में लग्न और बारह भाव जीवन के क्षेत्रों को दिखाते हैं; नवग्रह, भावेश और जन्म-नक्षत्र मिलकर उनके फल का संदर्भ देते हैं। आपकी सहेजी जन्म-तिथि से जो चंद्र राशि और नक्षत्र ऊपर दिए हैं, वे इस ऐप की प्रारंभिक गणना हैं। सटीक लग्न, ग्रह-डिग्री, नवांश और दशा के लिए प्रमाणित पंचांग/एपिमेरिस गणना अभी जुड़ी नहीं है। आप जिस भाव—विवाह, करियर, धन या परिवार—को समझना चाहते हैं, उसका नाम बताइए।`;
    }
    if (preferredLanguage === "english") {
      return `${greeting} ${personalContext}\n\nA Kundli is read through the Lagna and twelve Bhavas, with grahas, house lords, and the birth Nakshatra providing context. The Chandra Rashi and Nakshatra above are preliminary estimates from the saved birth date. Verified planetary degrees, Navamsha, and dasha require an ephemeris/Panchang calculation that is not configured in this app yet. Tell me which Bhava—marriage, career, money, or family—you want to explore.`;
    }
    return `${greeting} ${personalContext}\n\nKundli mein Lagna aur barah Bhava jeevan ke kshetra batate hain; Navagraha, bhavesh aur janma-nakshatra milkar unka sandarbh dete hain. Upar di gayi Chandra Rashi aur Nakshatra saved janm-tithi par app ki prarambhik ganana hai. Exact graha-degree, Navamsha aur dasha ke liye verified ephemeris/Panchang ganana abhi configure nahi hai. Aap jis bhav—vivah, career, dhan ya parivar—ko samajhna chahte hain, batayein.`;
  }

  const chartLine =
    effectiveRashi || effectiveNakshatra
      ? preferredLanguage === "hindi"
        ? `आपकी राशि **${effectiveRashi || "दर्ज नहीं"}** और नक्षत्र **${effectiveNakshatra || "दर्ज नहीं"}** को ध्यान में रखते हुए,`
        : preferredLanguage === "english"
          ? `With your recorded Rashi **${effectiveRashi || "not recorded"}** and Nakshatra **${effectiveNakshatra || "not recorded"}** in view,`
          : `Aapki darj rashi **${effectiveRashi || "uplabdh nahi"}** aur nakshatra **${effectiveNakshatra || "uplabdh nahi"}** ko dhyan mein rakhte hue,`
      : "";

  if (preferredLanguage === "hindi") {
    return `${greeting} ${personalContext}\n\n${chartLine} आपके प्रश्न “${userMessage.slice(0, 100)}” पर पारंपरिक ज्योतिष में पहले संबंधित भाव, उसके स्वामी और उस विषय को बल देने वाले ग्रह देखे जाते हैं। बारह भाव जीवन के अलग-अलग क्षेत्रों और नवग्रह उनके फल देने के माध्यम बताते हैं; दशा और गोचर समय का संदर्भ देते हैं।\n\nइस ऐप की कुंडली-गणना अभी प्रारंभिक है और सटीक दशा, नवांश तथा स्थानीय पंचांग नहीं निकालती। आप अपना प्रश्न किसी एक विषय—विवाह, करियर, धन या परिवार—तक सीमित करें; मैं उसी के शास्त्रीय संकेत और सरल उपाय स्पष्ट करूँगी।`;
  }
  if (preferredLanguage === "english") {
    return `${greeting} ${personalContext}\n\n${chartLine} a traditional reading first identifies the relevant Bhava, its lord, and the grahas that support or challenge that subject. The twelve Bhavas describe distinct areas of life; the Navagraha show how their results manifest, while dasha and gochara add timing.\n\nThis app's built-in chart is preliminary and does not calculate exact dasha, Navamsha, or local Panchang. Narrow your question to one area—marriage, career, money, or family—and I will explain the relevant classical factors and a simple upay.`;
  }
  return `${greeting} ${personalContext}\n\n${chartLine} paramparik Jyotish mein pehle sambandhit Bhava, uske swami aur us vishay ko bal dene wale grah dekhe jate hain. Barah Bhava jeevan ke alag kshetra batate hain; Navagraha phal dene ke madhyam hain, aur dasha-gochar samay ka sandarbh dete hain.\n\nApp ki built-in kundli ganana abhi prarambhik hai; exact dasha, Navamsha aur local Panchang nahi nikalti. Aap sawal ko ek vishay—vivah, career, dhan ya parivar—tak seemit karein, main uske shastriya sanket aur saral upay saaf bataungi.`;
}

function buildNumerologyReply(params: {
  userName: string;
  preferredLanguage: GitaChatContext["preferredLanguage"];
  birthDate: string | null;
  userMessage: string;
}): string {
  const { userName, preferredLanguage, birthDate, userMessage } = params;
  const greeting =
    preferredLanguage === "hindi"
      ? `नमस्ते ${userName} जी।`
      : `Namaste ${userName} ji.`;
  const dateParts = birthDate ? birthDate.split("-").map(Number) : [];
  const day = dateParts.length === 3 ? dateParts[2] : null;
  const birthNumber = day ? reduceToSingleDigit(day) : null;
  const lifePathNumber =
    dateParts.length === 3
      ? reduceToSingleDigit(
          dateParts.join("").split("").reduce((sum, digit) => sum + Number(digit), 0)
        )
      : null;
  const shouldCalculateName =
    /name|naam|नामांक|नाम का अंक|numerolog/i.test(userMessage);
  const nameNumber = shouldCalculateName
    ? calculateChaldeanNameNumber(userName)
    : null;

  const values = [
    birthNumber
      ? preferredLanguage === "hindi"
        ? `मूलांक **${birthNumber}** (जन्म-दिन ${day})`
        : `Moolank **${birthNumber}** (birth day ${day})`
      : "",
    lifePathNumber
      ? preferredLanguage === "hindi"
        ? `भाग्यांक **${lifePathNumber}** (पूरी जन्म-तिथि के अंकों से)`
        : `Bhagyank **${lifePathNumber}** (from the full birth date)`
      : "",
    nameNumber
      ? preferredLanguage === "hindi"
        ? `नामांक **${nameNumber}** (सहेजे हुए नाम की रोमन वर्तनी से)`
        : `Naamank **${nameNumber}** (from the saved name in Roman letters)`
      : "",
  ].filter(Boolean);

  if (!values.length) {
    if (preferredLanguage === "hindi") {
      return `${greeting} जन्म-तिथि प्रोफ़ाइल में नहीं है। मूलांक और भाग्यांक निकालने के लिए अपनी जन्म-तिथि दिन/महीना/वर्ष में लिखें।`;
    }
    if (preferredLanguage === "english") {
      return `${greeting} Your birth date is not in the profile. Share it as day/month/year and I can calculate your Moolank and Bhagyank.`;
    }
    return `${greeting} Aapki janm-tithi profile mein nahi hai. Moolank aur Bhagyank nikalne ke liye janm-tithi din/mahina/saal ke roop mein likhein.`;
  }

  const reading =
    preferredLanguage === "hindi"
      ? "पारंपरिक अंक-ज्योतिष में मूलांक जन्म-दिन की प्रवृत्ति और भाग्यांक पूरी जन्म-तिथि का संयुक्त संकेत माना जाता है। इन्हें आत्म-अनुशासन, संवाद और लक्ष्य-चयन के संकेत की तरह पढ़ा जाता है।"
      : preferredLanguage === "english"
        ? "In basic traditional numerology, the Moolank is read from the birth day and the Bhagyank from the full birth date. These numbers are traditionally used to reflect on habits, communication, and goal-setting."
        : "Paramparik ank-jyotish mein Moolank janm ke din se aur Bhagyank poori janm-tithi se dekha jata hai. In ankon ko aadat, sanchar aur lakshya chunne ke sanket ke roop mein padha jata hai.";
  const valuesLabel =
    preferredLanguage === "hindi"
      ? "आपके अंक"
      : preferredLanguage === "english"
        ? "Your ank"
        : "Aapke ank";
  return `${greeting} ${valuesLabel}: ${values.join("; ")}.\n\n${reading}`;
}

function calculateChaldeanNameNumber(name: string): number | null {
  const values: Record<string, number> = {
    A: 1, I: 1, J: 1, Q: 1, Y: 1,
    B: 2, K: 2, R: 2,
    C: 3, G: 3, L: 3, S: 3,
    D: 4, M: 4, T: 4,
    E: 5, H: 5, N: 5, X: 5,
    U: 6, V: 6, W: 6,
    O: 7, Z: 7,
    F: 8, P: 8,
  };
  const letters = name.toUpperCase().match(/[A-Z]/g) || [];
  if (!letters.length) return null;
  return reduceToSingleDigit(
    letters.reduce((sum, letter) => sum + (values[letter] || 0), 0)
  );
}

function reduceToSingleDigit(value: number): number {
  let result = Math.abs(Math.trunc(value));
  while (result > 9) {
    result = String(result)
      .split("")
      .reduce((sum, digit) => sum + Number(digit), 0);
  }
  return result;
}

function normalizeBirthDate(value?: string | null): string | null {
  if (!value) return null;
  const isoMatch = value.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  const localMatch = value.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/);
  if (!isoMatch && !localMatch) return null;
  const year = Number(isoMatch ? isoMatch[1] : localMatch?.[3]);
  const month = Number(isoMatch ? isoMatch[2] : localMatch?.[2]);
  const day = Number(isoMatch ? isoMatch[3] : localMatch?.[1]);
  const date = new Date(Date.UTC(year, month - 1, day));
  if (
    date.getUTCFullYear() !== year ||
    date.getUTCMonth() + 1 !== month ||
    date.getUTCDate() !== day
  ) {
    return null;
  }
  return `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

function extractBirthDate(message: string): string | null {
  const match = message.match(
    /\b(\d{4}-\d{1,2}-\d{1,2}|\d{1,2}[/-]\d{1,2}[/-]\d{4})\b/
  );
  return match ? normalizeBirthDate(match[1]) : null;
}
