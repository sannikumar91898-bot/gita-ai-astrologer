import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, kundliReadings, dailyHoroscopes } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import {
  ensureSeeded,
  getUserFromRequestHeaders,
} from "@/lib/server-utils";
import { calculateVedicKundli } from "@/lib/astrology";

export async function GET(req: NextRequest) {
  try {
    await ensureSeeded();
    let user = await getUserFromRequestHeaders(req.headers);

    if (!user) {
      const [defaultUser] = await db
        .select()
        .from(users)
        .where(eq(users.email, "aarav@gita-ai.in"));
      user = defaultUser || null;
    }

    const horoscopes = await db.select().from(dailyHoroscopes);

    const readings = user
      ? await db
          .select()
          .from(kundliReadings)
          .where(eq(kundliReadings.userId, user.id))
          .orderBy(desc(kundliReadings.createdAt))
      : [];

    const parsedReadings = readings.map((r) => {
      let houses = [];
      try {
        houses = JSON.parse(r.planetaryPositions);
      } catch {
        houses = [];
      }
      return {
        ...r,
        houses,
      };
    });

    return NextResponse.json({
      horoscopes,
      readings: parsedReadings,
    });
  } catch (error) {
    console.error("[API /kundli GET] Error:", error);
    return NextResponse.json(
      { error: "Failed to load Kundli & Horoscope data" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureSeeded();
    let user = await getUserFromRequestHeaders(req.headers);
    const body = await req.json();

    if (!user && body.userId) {
      const [found] = await db
        .select()
        .from(users)
        .where(eq(users.id, Number(body.userId)));
      user = found || null;
    }

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const name = String(body.name || user.name || "").trim();
    const birthDate = String(body.birthDate || "").trim();
    const birthTime = body.birthTime ? String(body.birthTime).trim() : null;
    const birthPlace = body.birthPlace ? String(body.birthPlace).trim() : null;

    // Input Validation
    if (!name || name.length < 2) {
      return NextResponse.json(
        { error: "Kripya vyakti ka poora naam darj karein (Name is required)." },
        { status: 400 }
      );
    }

    if (!birthDate || !/^\d{4}-\d{2}-\d{2}$/.test(birthDate)) {
      return NextResponse.json(
        {
          error:
            "Kripya sahi Janm Tithi (YYYY-MM-DD) chunein. Birth Date is mandatory.",
        },
        { status: 400 }
      );
    }

    const parsedYear = Number(birthDate.split("-")[0]);
    const currentYear = new Date().getFullYear();
    if (parsedYear < 1900 || parsedYear > currentYear) {
      return NextResponse.json(
        {
          error: `Birth year must be between 1900 and ${currentYear}.`,
        },
        { status: 400 }
      );
    }

    if (birthTime && !/^\d{2}:\d{2}$/.test(birthTime)) {
      return NextResponse.json(
        {
          error:
            "Optional Birth Time must be in HH:MM format (or leave blank if unknown).",
        },
        { status: 400 }
      );
    }

    const calculated = calculateVedicKundli({
      name,
      birthDate,
      birthTime,
      birthPlace,
    });

    const preferredLanguage = user.preferredLanguage;
    const interpretation =
      preferredLanguage === "hindi"
        ? calculated.summaryHindi
        : preferredLanguage === "english"
        ? calculated.summaryEnglish
        : calculated.summaryHinglish;

    const [savedReading] = await db
      .insert(kundliReadings)
      .values({
        userId: user.id,
        name,
        birthDate,
        birthTime,
        birthPlace,
        calculationMode: calculated.calculationMode,
        lagnaSign: calculated.lagnaSign,
        chandraRashi: calculated.chandraRashi,
        suryaRashi: calculated.suryaRashi,
        nakshatra: calculated.nakshatra,
        planetaryPositions: JSON.stringify(calculated.houses),
        aiInterpretation: interpretation,
      })
      .returning();

    // Also update user's primary profile birth details if requested
    if (body.saveToProfile !== false) {
      await db
        .update(users)
        .set({
          birthDate,
          birthTime,
          birthPlace,
          rashi: calculated.chandraRashi,
          nakshatra: calculated.nakshatra,
          updatedAt: new Date(),
        })
        .where(eq(users.id, user.id));
    }

    return NextResponse.json({
      reading: {
        ...savedReading,
        houses: calculated.houses,
        disclaimerLabel: calculated.disclaimerLabel,
        rulingPlanet: calculated.rulingPlanet,
        element: calculated.element,
      },
      message: "Kundli aur jyotish margdarshan safaltapoorvak taiyar ho gaya!",
    });
  } catch (error) {
    console.error("[API /kundli POST] Error:", error);
    return NextResponse.json(
      { error: "Failed to generate Kundli reading" },
      { status: 500 }
    );
  }
}
