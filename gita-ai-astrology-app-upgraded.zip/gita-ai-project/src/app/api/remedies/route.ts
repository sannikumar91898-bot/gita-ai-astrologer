import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, remedies } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import {
  ensureSeeded,
  getUserFromRequestHeaders,
} from "@/lib/server-utils";

export async function GET(req: NextRequest) {
  try {
    await ensureSeeded();
    let user = await getUserFromRequestHeaders(req.headers);

    if (!user) {
      const [defaultUser] = await db
        .select()
        .from(users)
        .where(eq(users.email, "aarav@gita-ai.in"));
      user = defaultUser || null;
    }

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userRemedies = await db
      .select()
      .from(remedies)
      .where(eq(remedies.userId, user.id))
      .orderBy(desc(remedies.createdAt));

    return NextResponse.json({ remedies: userRemedies });
  } catch (error) {
    console.error("[API /remedies GET] Error:", error);
    return NextResponse.json(
      { error: "Failed to load remedies" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureSeeded();
    let user = await getUserFromRequestHeaders(req.headers);
    const body = await req.json();

    if (!user && body.userId) {
      const [found] = await db
        .select()
        .from(users)
        .where(eq(users.id, Number(body.userId)));
      user = found || null;
    }

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { action } = body;

    if (action === "toggle_complete") {
      const remedyId = Number(body.remedyId);
      const [rem] = await db
        .select()
        .from(remedies)
        .where(eq(remedies.id, remedyId));

      if (!rem || rem.userId !== user.id) {
        return NextResponse.json(
          { error: "Remedy not found" },
          { status: 404 }
        );
      }

      const nextCompleted = !rem.isCompleted;
      const [updated] = await db
        .update(remedies)
        .set({
          isCompleted: nextCompleted,
          completedAt: nextCompleted ? new Date() : null,
          streakCount: nextCompleted
            ? rem.streakCount + 1
            : Math.max(0, rem.streakCount - 1),
        })
        .where(eq(remedies.id, remedyId))
        .returning();

      return NextResponse.json({ remedy: updated });
    }

    if (action === "add_remedy") {
      const title = String(body.title || "").trim();
      const category = String(body.category || "Mindfulness").trim();
      const description = String(body.description || "").trim();
      const mantraOrAction = body.mantraOrAction
        ? String(body.mantraOrAction).trim()
        : "5 Minute Shant Dhyan (Mindful Practice)";

      if (!title || !description) {
        return NextResponse.json(
          { error: "Title and description are required." },
          { status: 400 }
        );
      }

      const [created] = await db
        .insert(remedies)
        .values({
          userId: user.id,
          title,
          category,
          description,
          mantraOrAction,
          isCompleted: false,
          streakCount: 0,
        })
        .returning();

      return NextResponse.json({ remedy: created });
    }

    if (action === "delete_remedy") {
      const remedyId = Number(body.remedyId);
      await db.delete(remedies).where(eq(remedies.id, remedyId));
      return NextResponse.json({ deleted: true });
    }

    return NextResponse.json({ error: "Unsupported action" }, { status: 400 });
  } catch (error) {
    console.error("[API /remedies POST] Error:", error);
    return NextResponse.json(
      { error: "Failed to update remedy" },
      { status: 500 }
    );
  }
}
