import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, chatMessages, auditLogs } from "@/db/schema";
import { eq, asc } from "drizzle-orm";
import {
  ensureSeeded,
  getUserFromRequestHeaders,
  computeEntitlement,
} from "@/lib/server-utils";
import { generateGitaResponse } from "@/lib/gita-ai";
import { calculateVedicKundli } from "@/lib/astrology";

export async function GET(req: NextRequest) {
  try {
    await ensureSeeded();
    let user = await getUserFromRequestHeaders(req.headers);

    if (!user) {
      const [defaultUser] = await db
        .select()
        .from(users)
        .where(eq(users.email, "aarav@gita-ai.in"));
      user = defaultUser || null;
    }

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const messages = await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.userId, user.id))
      .orderBy(asc(chatMessages.createdAt));

    const entitlement = computeEntitlement(user);

    return NextResponse.json({
      messages,
      entitlement,
    });
  } catch (error) {
    console.error("[API /chat GET] Error:", error);
    return NextResponse.json(
      { error: "Failed to load chat history" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureSeeded();
    let user = await getUserFromRequestHeaders(req.headers);
    const body = await req.json();

    if (!user && body.userId) {
      const [found] = await db
        .select()
        .from(users)
        .where(eq(users.id, Number(body.userId)));
      user = found || null;
    }

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { action = "send_message" } = body;

    if (action === "toggle_save_reading") {
      const messageId = Number(body.messageId);
      const [msg] = await db
        .select()
        .from(chatMessages)
        .where(eq(chatMessages.id, messageId));

      if (!msg || msg.userId !== user.id) {
        return NextResponse.json(
          { error: "Message not found" },
          { status: 404 }
        );
      }

      const [updatedMsg] = await db
        .update(chatMessages)
        .set({ isSavedReading: !msg.isSavedReading })
        .where(eq(chatMessages.id, messageId))
        .returning();

      return NextResponse.json({ message: updatedMsg });
    }

    if (action === "clear_history") {
      await db.delete(chatMessages).where(eq(chatMessages.userId, user.id));
      const [welcome] = await db
        .insert(chatMessages)
        .values({
          userId: user.id,
          sessionId: `session-${Date.now()}`,
          topic: "Personal Guidance",
          role: "assistant",
          content: `Namaste ${user.name} ji! 🙏 Main Gita hoon. Aaj aap kya jaana chahte hain?`,
          isSavedReading: false,
        })
        .returning();

      return NextResponse.json({
        messages: [welcome],
        message: "Chat history cleared.",
      });
    }

    // Default: send_message
    const userMessageText = String(body.message || "").trim();
    const topic = String(body.topic || "Personal Guidance").trim();
    const sessionId = String(body.sessionId || "main-session");

    if (!userMessageText) {
      return NextResponse.json(
        { error: "Kripya apna sawal likhein (Please enter a message)." },
        { status: 400 }
      );
    }

    // 1. Check and enforce 15-second free trial or active ₹49/mo subscription on the server
    let currentUser = user;
    let entitlement = computeEntitlement(currentUser);

    if (entitlement.trialEligible && !entitlement.isSubscribed) {
      // Automatically start the 15-second trial on the user's first eligible chat!
      const now = new Date();
      const [startedUser] = await db
        .update(users)
        .set({
          trialStartedAt: now,
          trialUsed: true,
          subscriptionStatus: "trial",
          updatedAt: now,
        })
        .where(eq(users.id, currentUser.id))
        .returning();

      currentUser = startedUser;
      entitlement = computeEntitlement(currentUser);

      await db.insert(auditLogs).values({
        actorUserId: currentUser.id,
        targetUserId: currentUser.id,
        eventType: "TRIAL_STARTED_ON_FIRST_CHAT",
        details: JSON.stringify({
          startedAt: now.toISOString(),
          topic,
          durationSeconds: 15,
        }),
      });
    }

    if (!entitlement.canChat) {
      // Mark trial expired if it was in 'trial' state
      if (currentUser.subscriptionStatus === "trial") {
        await db
          .update(users)
          .set({ subscriptionStatus: "expired", updatedAt: new Date() })
          .where(eq(users.id, currentUser.id));
      }

      return NextResponse.json(
        {
          error:
            "Aapka 15-second free trial samapt ho gaya hai. Gita AI se asimit baat jari rakhne ke liye ₹49/month plan subscribe karein.",
          code: "TRIAL_EXPIRED_SUBSCRIPTION_REQUIRED",
          entitlement,
        },
        { status: 402 }
      );
    }

    // Optional inline birth details update if passed with message
    if (body.birthDate && body.birthDate !== currentUser.birthDate) {
      const k = calculateVedicKundli({
        name: currentUser.name,
        birthDate: String(body.birthDate),
        birthTime: body.birthTime ? String(body.birthTime) : currentUser.birthTime,
        birthPlace: body.birthPlace
          ? String(body.birthPlace)
          : currentUser.birthPlace,
      });
      const [u] = await db
        .update(users)
        .set({
          birthDate: String(body.birthDate),
          birthTime: body.birthTime ? String(body.birthTime) : currentUser.birthTime,
          birthPlace: body.birthPlace
            ? String(body.birthPlace)
            : currentUser.birthPlace,
          rashi: k.chandraRashi,
          nakshatra: k.nakshatra,
          updatedAt: new Date(),
        })
        .where(eq(users.id, currentUser.id))
        .returning();
      currentUser = u;
    }

    // 2. Fetch recent conversation context
    const existingMessages = await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.userId, currentUser.id))
      .orderBy(asc(chatMessages.createdAt));

    // 3. Save User Message
    const [savedUserMsg] = await db
      .insert(chatMessages)
      .values({
        userId: currentUser.id,
        sessionId,
        topic,
        role: "user",
        content: userMessageText,
        isSavedReading: false,
      })
      .returning();

    // 4. Generate Gita AI Response
    const preferredLanguage = (body.preferredLanguage ||
      currentUser.preferredLanguage ||
      "hinglish") as "hinglish" | "hindi" | "english";

    const { reply, engineUsed } = await generateGitaResponse({
      userName: currentUser.name,
      preferredLanguage,
      birthDate: currentUser.birthDate,
      birthTime: currentUser.birthTime,
      birthPlace: currentUser.birthPlace,
      rashi: currentUser.rashi,
      nakshatra: currentUser.nakshatra,
      topic,
      userMessage: userMessageText,
      history: existingMessages.slice(-8).map((m) => ({
        role: m.role,
        content: m.content,
      })),
    });

    // 5. Save Gita AI Reply
    const [savedAssistantMsg] = await db
      .insert(chatMessages)
      .values({
        userId: currentUser.id,
        sessionId,
        topic,
        role: "assistant",
        content: reply,
        isSavedReading: false,
      })
      .returning();

    return NextResponse.json({
      userMessage: savedUserMsg,
      assistantMessage: savedAssistantMsg,
      engineUsed,
      entitlement: computeEntitlement(currentUser),
    });
  } catch (error) {
    console.error("[API /chat POST] Error:", error);
    return NextResponse.json(
      { error: "Gita AI se sampark karne mein truti hui. Kripya punah prayas karein." },
      { status: 500 }
    );
  }
}
