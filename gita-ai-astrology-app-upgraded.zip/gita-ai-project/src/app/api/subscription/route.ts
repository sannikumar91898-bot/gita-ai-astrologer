import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, payments, auditLogs } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import {
  ensureSeeded,
  getUserFromRequestHeaders,
  computeEntitlement,
} from "@/lib/server-utils";
import {
  CONFIGURED_RECIPIENT_UPI_ID,
  SUBSCRIPTION_PRICE_INR,
  PAYMENT_WINDOW_SECONDS,
  MERCHANT_DETAILS,
  generateUniqueOrderReference,
  buildUpiPaymentLinks,
  getUpiVerificationConfiguration,
  verifyUpiPaymentWithProvider,
} from "@/lib/upi-verification";

function buildOrderPayload(
  paymentRecord: typeof payments.$inferSelect,
  customerUser: { id: number; name: string; email: string }
) {
  const createdMs = new Date(paymentRecord.createdAt).getTime();
  const expiresAtMs = createdMs + PAYMENT_WINDOW_SECONDS * 1000;
  const nowMs = Date.now();
  const remainingWindowSeconds = Math.max(
    0,
    Math.floor((expiresAtMs - nowMs) / 1000)
  );

  const upiLinks = buildUpiPaymentLinks(paymentRecord.orderId);
  const securePaymentLinkPath = `/pay/${encodeURIComponent(
    paymentRecord.orderId
  )}`;

  const recipientUpi =
    paymentRecord.recipientUpiId || CONFIGURED_RECIPIENT_UPI_ID;

  return {
    id: paymentRecord.id,
    userId: paymentRecord.userId,
    orderId: paymentRecord.orderId,
    recipientUpiId: recipientUpi,
    provider: paymentRecord.provider,
    amountInr: paymentRecord.amountInr,
    status: paymentRecord.status,
    submittedUtr: paymentRecord.submittedUtr,
    providerTransactionId: paymentRecord.providerTransactionId,
    verificationMethod: paymentRecord.verificationMethod,
    failureReason: paymentRecord.failureReason,
    createdAt: paymentRecord.createdAt,
    verifiedAt: paymentRecord.verifiedAt,
    expiresAt: new Date(expiresAtMs).toISOString(),
    remainingWindowSeconds,
    isWindowExpired:
      remainingWindowSeconds <= 0 && paymentRecord.status !== "verified",
    upiQrIntentUri: upiLinks.standardUpiUri,
    upiLinks,
    securePaymentLinkPath,
    merchantDetails: {
      ...MERCHANT_DETAILS,
      recipientUpiId: recipientUpi,
      merchantVpa: recipientUpi,
      orderId: paymentRecord.orderId,
    },
    customerAccount: {
      customerUserId: customerUser.id,
      customerName: customerUser.name,
      customerEmail: customerUser.email,
    },
  };
}

export async function GET(req: NextRequest) {
  try {
    await ensureSeeded();
    const { searchParams } = new URL(req.url);
    const requestedOrderId = searchParams.get("orderId");
    const gatewayConfig = getUpiVerificationConfiguration();

    if (requestedOrderId) {
      const [paymentRecord] = await db
        .select()
        .from(payments)
        .where(eq(payments.orderId, requestedOrderId));

      if (!paymentRecord) {
        return NextResponse.json(
          { error: "Payment order not found" },
          { status: 404 }
        );
      }

      const [beneficiaryUser] = await db
        .select()
        .from(users)
        .where(eq(users.id, paymentRecord.userId));

      if (!beneficiaryUser) {
        return NextResponse.json(
          { error: "Beneficiary user not found" },
          { status: 404 }
        );
      }

      let currentRecord = paymentRecord;
      const createdMs = new Date(paymentRecord.createdAt).getTime();
      const elapsedSeconds = Math.floor((Date.now() - createdMs) / 1000);

      // Never expire an already verified payment
      if (
        elapsedSeconds >= PAYMENT_WINDOW_SECONDS &&
        (paymentRecord.status === "pending" ||
          paymentRecord.status === "created")
      ) {
        const [expiredPayment] = await db
          .update(payments)
          .set({
            status: "expired",
            failureReason:
              "5-minute payment window expired before verified bank/gateway confirmation was received.",
          })
          .where(eq(payments.id, paymentRecord.id))
          .returning();
        currentRecord = expiredPayment;
      }

      return NextResponse.json({
        order: buildOrderPayload(currentRecord, beneficiaryUser),
        entitlement: computeEntitlement(beneficiaryUser),
        gatewayConfig,
      });
    }

    let user = await getUserFromRequestHeaders(req.headers);

    if (!user) {
      const [defaultUser] = await db
        .select()
        .from(users)
        .where(eq(users.email, "aarav@gita-ai.in"));
      user = defaultUser || null;
    }

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userPayments = await db
      .select()
      .from(payments)
      .where(eq(payments.userId, user.id))
      .orderBy(desc(payments.createdAt));

    return NextResponse.json({
      entitlement: computeEntitlement(user),
      merchantDetails: {
        ...MERCHANT_DETAILS,
      },
      customerAccount: {
        customerUserId: user.id,
        customerName: user.name,
        customerEmail: user.email,
      },
      subscriptionPlan: {
        id: "monthly_49",
        name: "Gita AI Premium Monthly",
        priceInr: SUBSCRIPTION_PRICE_INR,
        recipientUpiId: CONFIGURED_RECIPIENT_UPI_ID,
        billingPeriod: "1 Month (30 Days)",
        autoRenewalTerms: `₹${SUBSCRIPTION_PRICE_INR}/month paid directly to ${CONFIGURED_RECIPIENT_UPI_ID}. Premium activates only after independent server-side payment verification.`,
      },
      gatewayConfig,
      payments: userPayments,
    });
  } catch (error) {
    console.error("[API /subscription GET] Error:", error);
    return NextResponse.json(
      { error: "Failed to fetch subscription details" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureSeeded();
    let user = await getUserFromRequestHeaders(req.headers);
    const body = await req.json();

    if (!user && body.userId) {
      const [found] = await db
        .select()
        .from(users)
        .where(eq(users.id, Number(body.userId)));
      user = found || null;
    }

    const { action } = body;
    const gatewayConfig = getUpiVerificationConfiguration();

      if (
        !user &&
        body.orderId &&
        (action === "verify_payment" ||
          action === "verify_webhook_or_status" ||
          action === "check_order_status" ||
          action === "expire_order_window" ||
          action === "report_upi_decline")
      ) {
      const [payRec] = await db
        .select()
        .from(payments)
        .where(eq(payments.orderId, String(body.orderId)));
      if (payRec) {
        const [beneficiary] = await db
          .select()
          .from(users)
          .where(eq(users.id, payRec.userId));
        user = beneficiary || null;
      }
    }

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // 1. CREATE UNIQUE ORDER FOR 7250595155@ibl (₹49/month)
    if (action === "create_order") {
      const provider = String(body.provider || "phonepe");
      const explicitConsent = Boolean(body.explicitConsent);

      if (!explicitConsent) {
        return NextResponse.json(
          {
            error:
              "Explicit billing consent is required before initiating a ₹49/month UPI subscription order.",
          },
          { status: 400 }
        );
      }

      const orderId = generateUniqueOrderReference(user.id);
      const upiCheck = buildUpiPaymentLinks(orderId);
      if (!upiCheck.validation.valid) {
        return NextResponse.json(
          {
            error: `UPI payment request validation failed: ${upiCheck.validation.errors.join(
              " "
            )}`,
          },
          { status: 400 }
        );
      }

      const [createdPayment] = await db
        .insert(payments)
        .values({
          userId: user.id,
          orderId,
          recipientUpiId: CONFIGURED_RECIPIENT_UPI_ID,
          provider,
          amountInr: SUBSCRIPTION_PRICE_INR,
          status: "pending",
          verificationMethod: gatewayConfig.anyLiveVerificationConfigured
            ? "awaiting_provider_verification"
            : "verification_unavailable_missing_merchant_api",
          failureReason: gatewayConfig.anyLiveVerificationConfigured
            ? `Waiting for ₹${SUBSCRIPTION_PRICE_INR} payment to ${CONFIGURED_RECIPIENT_UPI_ID}.`
            : gatewayConfig.missingCredentialsExplanation,
        })
        .returning();

      const currentEnt = computeEntitlement(user);
      if (!currentEnt.isSubscribed) {
        await db
          .update(users)
          .set({
            subscriptionStatus: "pending",
            updatedAt: new Date(),
          })
          .where(eq(users.id, user.id));
      }

      await db.insert(auditLogs).values({
        actorUserId: user.id,
        targetUserId: user.id,
        eventType: "UPI_ORDER_CREATED",
        details: JSON.stringify({
          orderId,
          recipientUpiId: CONFIGURED_RECIPIENT_UPI_ID,
          provider,
          amountInr: SUBSCRIPTION_PRICE_INR,
          anyLiveVerificationConfigured:
            gatewayConfig.anyLiveVerificationConfigured,
        }),
      });

      const orderPayload = buildOrderPayload(createdPayment, user);

      return NextResponse.json({
        order: orderPayload,
        gatewayConfig,
        setupMessage: !gatewayConfig.anyLiveVerificationConfigured
          ? gatewayConfig.missingCredentialsExplanation
          : null,
      });
    }

    // 2. INDEPENDENT SERVER-SIDE VERIFICATION / UTR LOOKUP (NO FAKE OR SIMULATED UNLOCKS)
    if (
      action === "verify_payment" ||
      action === "check_order_status" ||
      action === "verify_webhook_or_status"
    ) {
      const orderId = String(body.orderId || "").trim();
      const rawSubmittedUtr = body.utr ? String(body.utr).trim() : null;

      if (!orderId) {
        return NextResponse.json(
          { error: "Order ID is required for payment verification." },
          { status: 400 }
        );
      }

      const [paymentRecord] = await db
        .select()
        .from(payments)
        .where(eq(payments.orderId, orderId));

      if (!paymentRecord) {
        return NextResponse.json(
          { error: "Payment order not found on server." },
          { status: 404 }
        );
      }

      // Ensure order is strictly matched to the authenticated Gita AI user account
      if (user && paymentRecord.userId !== user.id) {
        return NextResponse.json(
          {
            verified: false,
            error:
              "Order mismatch: This order belongs to a different Gita AI user account.",
          },
          { status: 403 }
        );
      }

      if (
        paymentRecord.recipientUpiId !== CONFIGURED_RECIPIENT_UPI_ID ||
        paymentRecord.amountInr !== SUBSCRIPTION_PRICE_INR
      ) {
        return NextResponse.json(
          {
            verified: false,
            error: `Order recipient/amount mismatch: expected ₹${SUBSCRIPTION_PRICE_INR} to ${CONFIGURED_RECIPIENT_UPI_ID}.`,
          },
          { status: 422 }
        );
      }

      const [customerUser] = await db
        .select()
        .from(users)
        .where(eq(users.id, paymentRecord.userId));
      const targetUser = customerUser || user;

      // Idempotent guard: never reject an already verified payment
      if (paymentRecord.status === "verified") {
        return NextResponse.json({
          verified: true,
          payment: buildOrderPayload(paymentRecord, targetUser),
          entitlement: computeEntitlement(targetUser),
          statusLabel: "Payment successful",
          message:
            "Payment successful! This ₹49 payment to " +
            CONFIGURED_RECIPIENT_UPI_ID +
            " is already verified on the server.",
        });
      }

      // Validate UTR format if user submitted one (standard 12-digit UPI UTR / RRN)
      if (rawSubmittedUtr) {
        if (!/^[A-Za-z0-9]{10,22}$/.test(rawSubmittedUtr)) {
          return NextResponse.json(
            {
              verified: false,
              error:
                "Invalid UTR / UPI Reference format. A valid NPCI UPI UTR is a 12-digit numeric reference (RRN).",
              payment: buildOrderPayload(paymentRecord, targetUser),
              entitlement: computeEntitlement(targetUser),
            },
            { status: 400 }
          );
        }

        // Record the user-submitted UTR for audit, but DO NOT trust it without provider verification
        await db
          .update(payments)
          .set({
            submittedUtr: rawSubmittedUtr,
          })
          .where(eq(payments.id, paymentRecord.id));
        paymentRecord.submittedUtr = rawSubmittedUtr;
      }

      // Check if user or caller tried to trigger a client-side simulated unlock
      if (body.outcome === "verified" || body.simulatedSuccess === true) {
        await db.insert(auditLogs).values({
          actorUserId: targetUser.id,
          targetUserId: targetUser.id,
          eventType: "REJECTED_UNVERIFIED_CLIENT_UNLOCK_ATTEMPT",
          details: JSON.stringify({
            orderId,
            submittedUtr: rawSubmittedUtr,
            reason:
              "Client attempted to unlock Premium without independent bank/gateway verification.",
          }),
        });
      }

      // Perform independent server-to-server verification against configured provider/bank API
      const verificationResult = await verifyUpiPaymentWithProvider({
        orderId: paymentRecord.orderId,
        expectedAmountInr: SUBSCRIPTION_PRICE_INR,
        expectedRecipientVpa: CONFIGURED_RECIPIENT_UPI_ID,
        submittedUtr: rawSubmittedUtr || paymentRecord.submittedUtr,
      });

      // CASE A: Automatic verification is unavailable (no live merchant API keys configured for 7250595155@ibl)
      if (verificationResult.status === "verification_unavailable") {
        const [updatedPayment] = await db
          .update(payments)
          .set({
            status: "pending",
            verificationMethod: "verification_unavailable_missing_merchant_api",
            failureReason: verificationResult.reason,
          })
          .where(eq(payments.id, paymentRecord.id))
          .returning();

        await db.insert(auditLogs).values({
          actorUserId: targetUser.id,
          targetUserId: targetUser.id,
          eventType: "VERIFICATION_BLOCKED_NO_MERCHANT_API",
          details: JSON.stringify({
            orderId: paymentRecord.orderId,
            recipientUpiId: CONFIGURED_RECIPIENT_UPI_ID,
            submittedUtr: rawSubmittedUtr,
            note: "Premium kept locked: standalone UPI VPA cannot be automatically verified without PhonePe PG, Razorpay, or Bank Aggregator API credentials.",
          }),
        });

        return NextResponse.json(
          {
            verified: false,
            code: "AUTOMATIC_VERIFICATION_UNAVAILABLE",
            statusLabel: "Waiting for payment (Verification API Required)",
            error: verificationResult.reason,
            message: verificationResult.reason,
            requiredSetupSteps: gatewayConfig.requiredSetupSteps,
            payment: buildOrderPayload(updatedPayment, targetUser),
            entitlement: computeEntitlement(targetUser),
            gatewayConfig,
          },
          { status: 422 }
        );
      }

      // CASE B: Provider independently confirmed the ₹49 payment to 7250595155@ibl!
      if (verificationResult.verified) {
        const verifiedUtr =
          verificationResult.verifiedTransactionId ||
          rawSubmittedUtr ||
          paymentRecord.orderId;

        // Ensure UTR has never been used on another order
        const [existingUtrOrder] = await db
          .select()
          .from(payments)
          .where(eq(payments.providerTransactionId, verifiedUtr));

        if (
          existingUtrOrder &&
          existingUtrOrder.orderId !== paymentRecord.orderId
        ) {
          return NextResponse.json(
            {
              verified: false,
              error: `UTR ${verifiedUtr} has already been used for another order (${existingUtrOrder.orderId}).`,
              payment: buildOrderPayload(paymentRecord, targetUser),
              entitlement: computeEntitlement(targetUser),
            },
            { status: 409 }
          );
        }

        const now = new Date();
        const expiresAt = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

        const [updatedPayment] = await db
          .update(payments)
          .set({
            status: "verified",
            providerTransactionId: verifiedUtr,
            verificationMethod: `verified_by_${verificationResult.providerUsed}`,
            failureReason: null,
            verifiedAt: now,
          })
          .where(eq(payments.id, paymentRecord.id))
          .returning();

        const [updatedUser] = await db
          .update(users)
          .set({
            subscriptionStatus: "active",
            subscriptionPlan: "monthly_49",
            subscriptionExpiresAt: expiresAt,
            trialUsed: true,
            updatedAt: now,
          })
          .where(eq(users.id, targetUser.id))
          .returning();

        await db.insert(auditLogs).values({
          actorUserId: targetUser.id,
          targetUserId: targetUser.id,
          eventType: "PAYMENT_VERIFIED_SUBSCRIPTION_ACTIVE",
          details: JSON.stringify({
            orderId: paymentRecord.orderId,
            recipientUpiId: CONFIGURED_RECIPIENT_UPI_ID,
            verifiedTransactionId: verifiedUtr,
            providerUsed: verificationResult.providerUsed,
            amountInr: SUBSCRIPTION_PRICE_INR,
            expiresAt: expiresAt.toISOString(),
          }),
        });

        return NextResponse.json({
          verified: true,
          payment: buildOrderPayload(updatedPayment, updatedUser),
          entitlement: computeEntitlement(updatedUser),
          statusLabel: "Payment successful",
          message: `Payment successful! ₹${SUBSCRIPTION_PRICE_INR} payment to ${CONFIGURED_RECIPIENT_UPI_ID} verified via ${verificationResult.providerUsed}. Premium is now unlocked!`,
        });
      }

      // CASE C: Provider reported payment failed
      if (verificationResult.status === "failed") {
        const [updatedPayment] = await db
          .update(payments)
          .set({
            status: "failed",
            verificationMethod: verificationResult.providerUsed,
            failureReason: verificationResult.reason,
          })
          .where(eq(payments.id, paymentRecord.id))
          .returning();

        return NextResponse.json(
          {
            verified: false,
            payment: buildOrderPayload(updatedPayment, targetUser),
            entitlement: computeEntitlement(targetUser),
            statusLabel: "Payment failed",
            error: verificationResult.reason,
            message: verificationResult.reason,
          },
          { status: 402 }
        );
      }

      // CASE D: Still pending on provider
      return NextResponse.json({
        verified: false,
        payment: buildOrderPayload(paymentRecord, targetUser),
        entitlement: computeEntitlement(targetUser),
        statusLabel: "Waiting for payment",
        message: verificationResult.reason,
      });
    }

    // 3. RECORD ACTUAL UPI APP / BANK DECLINE REASON (No auto-retry)
    if (action === "report_upi_decline") {
      const orderId = String(body.orderId || "").trim();
      const rawReason = String(
        body.failureReason ||
          "Your payment is declined for security reasons. Please try using a mobile number, UPI ID, or QR code."
      ).trim();

      const [paymentRecord] = await db
        .select()
        .from(payments)
        .where(eq(payments.orderId, orderId));

      if (!paymentRecord) {
        return NextResponse.json(
          { error: "Payment order not found" },
          { status: 404 }
        );
      }

      const [customerUser] = await db
        .select()
        .from(users)
        .where(eq(users.id, paymentRecord.userId));
      const targetUser = customerUser || user;

      // Never overwrite an already verified order
      if (paymentRecord.status === "verified") {
        return NextResponse.json({
          payment: buildOrderPayload(paymentRecord, targetUser),
          entitlement: computeEntitlement(targetUser),
          statusLabel: "Payment successful",
          message:
            "Payment successful! This order was already verified on the server.",
        });
      }

      const detailedFailureReason = `${rawReason} (Technical Cause: NPCI Circular OC-79/OC-154 blocks unsigned browser deep-link intents to non-merchant/personal UPI IDs like ${CONFIGURED_RECIPIENT_UPI_ID}, whereas scanning the QR code uses trusted camera mode=01. Use the QR Code above or register ${CONFIGURED_RECIPIENT_UPI_ID} as a verified P2M merchant VPA with cryptographic intent signing.)`;

      const [failedPayment] = await db
        .update(payments)
        .set({
          status: "failed",
          verificationMethod: "upi_app_security_decline_reported",
          failureReason: detailedFailureReason,
        })
        .where(eq(payments.id, paymentRecord.id))
        .returning();

      await db.insert(auditLogs).values({
        actorUserId: targetUser.id,
        targetUserId: targetUser.id,
        eventType: "UPI_APP_SECURITY_DECLINE_RECORDED",
        details: JSON.stringify({
          orderId: paymentRecord.orderId,
          recipientUpiId: CONFIGURED_RECIPIENT_UPI_ID,
          reportedReason: rawReason,
        }),
      });

      return NextResponse.json({
        verified: false,
        payment: buildOrderPayload(failedPayment, targetUser),
        entitlement: computeEntitlement(targetUser),
        statusLabel: "Payment failed",
        error: detailedFailureReason,
        message: detailedFailureReason,
      });
    }

    // 4. EXPIRE 5-MINUTE PAYMENT WINDOW (Never expires an already-verified payment)
    if (action === "expire_order_window") {
      const orderId = String(body.orderId || "").trim();
      const [paymentRecord] = await db
        .select()
        .from(payments)
        .where(eq(payments.orderId, orderId));

      if (!paymentRecord) {
        return NextResponse.json(
          { error: "Order not found" },
          { status: 404 }
        );
      }

      const [beneficiary] = await db
        .select()
        .from(users)
        .where(eq(users.id, paymentRecord.userId));
      const targetUser = beneficiary || user;

      if (paymentRecord.status === "verified") {
        return NextResponse.json({
          payment: buildOrderPayload(paymentRecord, targetUser),
          entitlement: computeEntitlement(targetUser),
          statusLabel: "Payment successful",
          message:
            "Payment successful! Your payment was already confirmed by the server.",
        });
      }

      const [expiredPayment] = await db
        .update(payments)
        .set({
          status: "expired",
          verificationMethod: "payment_window_timeout_5m",
          failureReason:
            "5-minute payment window expired. Please tap Retry Payment to generate a fresh unique order reference and QR code.",
        })
        .where(eq(payments.id, paymentRecord.id))
        .returning();

      return NextResponse.json({
        payment: buildOrderPayload(expiredPayment, targetUser),
        entitlement: computeEntitlement(targetUser),
        statusLabel: "Payment window expired",
        message:
          "5-minute payment window expired. Tap Retry Payment to generate a new order reference.",
      });
    }

    if (action === "cancel_subscription") {
      const [updatedUser] = await db
        .update(users)
        .set({
          subscriptionStatus: "cancelled",
          subscriptionExpiresAt: new Date(Date.now() - 1000),
          updatedAt: new Date(),
        })
        .where(eq(users.id, user.id))
        .returning();

      await db.insert(auditLogs).values({
        actorUserId: user.id,
        targetUserId: user.id,
        eventType: "SUBSCRIPTION_CANCELLED",
        details: JSON.stringify({
          cancelledAt: new Date().toISOString(),
          plan: "monthly_49",
        }),
      });

      return NextResponse.json({
        entitlement: computeEntitlement(updatedUser),
        message:
          "Your ₹49/month subscription has been cancelled. Future auto-renewals are stopped.",
      });
    }

    if (action === "simulate_expiry") {
      const pastDate = new Date(Date.now() - 86400000);
      const [updatedUser] = await db
        .update(users)
        .set({
          subscriptionStatus: "expired",
          subscriptionExpiresAt: pastDate,
          trialUsed: true,
          updatedAt: new Date(),
        })
        .where(eq(users.id, user.id))
        .returning();

      return NextResponse.json({
        entitlement: computeEntitlement(updatedUser),
        message:
          "Subscription billing cycle expired. Renew for ₹49/month to restore unlimited chat access.",
      });
    }

    if (action === "restore_purchases") {
      const userPayments = await db
        .select()
        .from(payments)
        .where(eq(payments.userId, user.id))
        .orderBy(desc(payments.createdAt));

      const latestVerified = userPayments.find(
        (p) =>
          p.status === "verified" &&
          p.recipientUpiId === CONFIGURED_RECIPIENT_UPI_ID &&
          p.amountInr === SUBSCRIPTION_PRICE_INR &&
          Boolean(p.providerTransactionId)
      );

      if (!latestVerified) {
        return NextResponse.json(
          {
            restored: false,
            entitlement: computeEntitlement(user),
            message: `No verified ₹${SUBSCRIPTION_PRICE_INR}/month payment to ${CONFIGURED_RECIPIENT_UPI_ID} was found on the server for your account.`,
          },
          { status: 404 }
        );
      }

      const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
      const [updatedUser] = await db
        .update(users)
        .set({
          subscriptionStatus: "active",
          subscriptionExpiresAt: expiresAt,
          updatedAt: new Date(),
        })
        .where(eq(users.id, user.id))
        .returning();

      return NextResponse.json({
        restored: true,
        entitlement: computeEntitlement(updatedUser),
        message: `Purchase restored! Verified Order ${latestVerified.orderId} is now active.`,
      });
    }

    return NextResponse.json({ error: "Unsupported action" }, { status: 400 });
  } catch (error) {
    console.error("[API /subscription POST] Error:", error);
    return NextResponse.json(
      { error: "Subscription operation failed" },
      { status: 500 }
    );
  }
}
