import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  users,
  payments,
  auditLogs,
  dailyHoroscopes,
  appConfig,
  chatMessages,
  kundliReadings,
} from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import {
  ensureSeeded,
  getUserFromRequestHeaders,
  computeEntitlement,
} from "@/lib/server-utils";

async function verifyAdminAccess(req: NextRequest) {
  await ensureSeeded();
  const user = await getUserFromRequestHeaders(req.headers);
  if (user && user.role === "admin") {
    return user;
  }
  return null;
}

export async function GET(req: NextRequest) {
  try {
    const adminUser = await verifyAdminAccess(req);
    if (!adminUser) {
      return NextResponse.json(
        {
          error:
            "Access Denied (403 Forbidden): Administrator role required to access the Admin Dashboard.",
          code: "ADMIN_RBAC_REQUIRED",
        },
        { status: 403 }
      );
    }

    const allUsers = await db
      .select()
      .from(users)
      .orderBy(desc(users.createdAt));
    const allPayments = await db
      .select()
      .from(payments)
      .orderBy(desc(payments.createdAt));
    const allLogs = await db
      .select()
      .from(auditLogs)
      .orderBy(desc(auditLogs.createdAt));
    const horoscopes = await db.select().from(dailyHoroscopes);
    const configs = await db.select().from(appConfig);
    const allMessages = await db.select().from(chatMessages);
    const allKundlis = await db.select().from(kundliReadings);

    // Never expose password hashes, private chat content, or sensitive personal identifiers
    const sanitizedUsers = allUsers.map((u) => {
      const ent = computeEntitlement(u);
      const maskedEmail = u.email.replace(
        /^(.)(.*)(@.*)$/,
        (_, first, mid, domain) =>
          `${first}${"*".repeat(Math.min(4, mid.length))}${domain}`
      );
      return {
        id: u.id,
        name: u.name,
        maskedEmail,
        role: u.role,
        preferredLanguage: u.preferredLanguage,
        rashi: u.rashi,
        trialUsed: u.trialUsed,
        subscriptionStatus: ent.subscriptionStatus,
        subscriptionPlan: u.subscriptionPlan,
        subscriptionExpiresAt: u.subscriptionExpiresAt,
        createdAt: u.createdAt,
      };
    });

    const verifiedPayments = allPayments.filter((p) => p.status === "verified");
    const totalVerifiedRevenueInr = verifiedPayments.reduce(
      (sum, p) => sum + p.amountInr,
      0
    );

    const stats = {
      totalUsers: allUsers.length,
      activeSubscribers: sanitizedUsers.filter(
        (u) => u.subscriptionStatus === "active"
      ).length,
      trialUsers: sanitizedUsers.filter(
        (u) => u.subscriptionStatus === "trial" || !u.trialUsed
      ).length,
      expiredOrCancelledUsers: sanitizedUsers.filter(
        (u) =>
          u.subscriptionStatus === "expired" ||
          u.subscriptionStatus === "cancelled"
      ).length,
      totalPaymentsCount: allPayments.length,
      verifiedPaymentsCount: verifiedPayments.length,
      pendingPaymentsCount: allPayments.filter((p) => p.status === "pending")
        .length,
      failedPaymentsCount: allPayments.filter((p) => p.status === "failed")
        .length,
      refundedPaymentsCount: allPayments.filter((p) => p.status === "refunded")
        .length,
      totalVerifiedRevenueInr,
      totalChatInteractionsCount: allMessages.length,
      totalKundliChartsCount: allKundlis.length,
    };

    return NextResponse.json({
      admin: {
        id: adminUser.id,
        name: adminUser.name,
        role: adminUser.role,
      },
      stats,
      users: sanitizedUsers,
      payments: allPayments,
      auditLogs: allLogs.slice(0, 50),
      horoscopes,
      configs,
    });
  } catch (error) {
    console.error("[API /admin GET] Error:", error);
    return NextResponse.json(
      { error: "Failed to load admin dashboard data" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const adminUser = await verifyAdminAccess(req);
    if (!adminUser) {
      return NextResponse.json(
        {
          error:
            "Access Denied (403 Forbidden): Ordinary users cannot perform administrator actions.",
        },
        { status: 403 }
      );
    }

    const body = await req.json();
    const { action } = body;

    if (action === "update_horoscope") {
      const id = Number(body.id);
      const dailyForecastHinglish = String(
        body.dailyForecastHinglish || ""
      ).trim();
      const dailyForecastHindi = String(body.dailyForecastHindi || "").trim();
      const dailyForecastEnglish = String(
        body.dailyForecastEnglish || ""
      ).trim();
      const luckyColor = String(body.luckyColor || "").trim();
      const luckyNumber = String(body.luckyNumber || "").trim();
      const positiveHabit = String(body.positiveHabit || "").trim();

      const [updated] = await db
        .update(dailyHoroscopes)
        .set({
          dailyForecastHinglish,
          dailyForecastHindi,
          dailyForecastEnglish,
          luckyColor,
          luckyNumber,
          positiveHabit,
          updatedAt: new Date(),
        })
        .where(eq(dailyHoroscopes.id, id))
        .returning();

      await db.insert(auditLogs).values({
        actorUserId: adminUser.id,
        targetUserId: null,
        eventType: "ADMIN_HOROSCOPE_UPDATED",
        details: JSON.stringify({
          rashi: updated?.rashi,
          luckyColor,
          luckyNumber,
        }),
      });

      return NextResponse.json({
        horoscope: updated,
        message: `Updated daily horoscope for ${updated?.rashi}`,
      });
    }

    if (action === "update_config") {
      const key = String(body.key || "").trim();
      const value = String(body.value || "").trim();

      if (!key) {
        return NextResponse.json(
          { error: "Config key is required" },
          { status: 400 }
        );
      }

      await db
        .insert(appConfig)
        .values({ key, value, updatedAt: new Date() })
        .onConflictDoUpdate({
          target: appConfig.key,
          set: { value, updatedAt: new Date() },
        });

      await db.insert(auditLogs).values({
        actorUserId: adminUser.id,
        targetUserId: null,
        eventType: "ADMIN_CONFIG_UPDATED",
        details: JSON.stringify({ key, value }),
      });

      return NextResponse.json({
        message: `Configuration '${key}' updated successfully.`,
      });
    }

    if (action === "admin_update_subscription") {
      const targetUserId = Number(body.targetUserId);
      const newStatus = String(body.status || "expired");

      if (newStatus === "active") {
        const userPayments = await db
          .select()
          .from(payments)
          .where(eq(payments.userId, targetUserId));
        const hasVerifiedPayment = userPayments.some(
          (p) =>
            p.status === "verified" &&
            p.recipientUpiId === "7250595155@ibl" &&
            p.amountInr === 49 &&
            Boolean(p.providerTransactionId)
        );
        if (!hasVerifiedPayment) {
          return NextResponse.json(
            {
              error:
                "Cannot activate Premium without a genuinely verified ₹49 payment to 7250595155@ibl.",
            },
            { status: 422 }
          );
        }
      }

      const expiresAt =
        newStatus === "active"
          ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
          : new Date(Date.now() - 1000);

      const [updatedUser] = await db
        .update(users)
        .set({
          subscriptionStatus: newStatus,
          subscriptionExpiresAt: expiresAt,
          trialUsed: newStatus === "none" ? false : true,
          trialStartedAt: newStatus === "none" ? null : undefined,
          updatedAt: new Date(),
        })
        .where(eq(users.id, targetUserId))
        .returning();

      await db.insert(auditLogs).values({
        actorUserId: adminUser.id,
        targetUserId,
        eventType: "ADMIN_SUBSCRIPTION_STATUS_CHANGED",
        details: JSON.stringify({
          newStatus,
          reason: body.reason || "Manual admin status audit override",
        }),
      });

      return NextResponse.json({
        user: updatedUser,
        message: `User #${targetUserId} subscription status updated to '${newStatus}' and logged in audit trail.`,
      });
    }

    return NextResponse.json({ error: "Unsupported action" }, { status: 400 });
  } catch (error) {
    console.error("[API /admin POST] Error:", error);
    return NextResponse.json(
      { error: "Admin operation failed" },
      { status: 500 }
    );
  }
}
