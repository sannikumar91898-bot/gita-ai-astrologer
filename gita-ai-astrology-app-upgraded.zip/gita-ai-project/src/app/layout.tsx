import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import {
  Rozha_One,
  Plus_Jakarta_Sans,
  Noto_Sans_Devanagari,
  JetBrains_Mono,
} from "next/font/google";
import "./globals.css";

const rozha = Rozha_One({
  weight: "400",
  subsets: ["latin", "devanagari"],
  variable: "--font-rozha",
});

const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-jakarta",
});

const devanagari = Noto_Sans_Devanagari({
  subsets: ["devanagari"],
  variable: "--font-devanagari",
});

const jetbrains = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jetbrains",
});

export const metadata: Metadata = {
  title: "Gita AI – Your Favorite Astrologer | Vedic AI Jyotish",
  description:
    "Smart, friendly, personalized Indian AI Astrologer in Hindi, Hinglish, and English. 15-second free chat trial, Kundli analysis, Daily Horoscope, and ₹49/month subscription.",
  manifest: "/manifest.json",
};

export const viewport: Viewport = {
  themeColor: "#7C2D86",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="en"
      className={`${rozha.variable} ${jakarta.variable} ${devanagari.variable} ${jetbrains.variable}`}
    >
      <body className="bg-[#FFF9F5] text-[#2A162D] font-sans-vedic antialiased selection:bg-[#7C2D86] selection:text-white">
        {children}
      </body>
    </html>
  );
}
